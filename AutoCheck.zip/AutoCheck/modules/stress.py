import math
import os
import time
import multiprocessing as mp
import psutil
from core.models import Finding
from core.utils import nvidia_smi_query, to_float, temp_file_path
from core.torch_env import discover_cuda_python, run_external_cuda_stress


def cpu_burn_worker(stop_event, duty):
    period = 0.10
    busy_time = max(0.01, min(0.099, period * duty))
    while not stop_event.is_set():
        start = time.perf_counter()
        x = 0.0
        while (time.perf_counter() - start) < busy_time:
            x += math.sqrt(12345.6789) * math.sin(x + 1.2345)
        sleep_time = period - busy_time
        if sleep_time > 0:
            time.sleep(sleep_time)


def disk_test(size_mb):
    path = temp_file_path(prefix="autocheck_diskstress_", suffix=".bin")
    block = os.urandom(1024 * 1024)
    try:
        start = time.perf_counter()
        with open(path, "wb") as f:
            for _ in range(size_mb):
                f.write(block)
            f.flush()
            os.fsync(f.fileno())
        write_s = max(0.001, time.perf_counter() - start)

        start = time.perf_counter()
        with open(path, "rb") as f:
            while f.read(1024 * 1024):
                pass
        read_s = max(0.001, time.perf_counter() - start)
        return size_mb / write_s, size_mb / read_s
    finally:
        try:
            os.remove(path)
        except Exception:
            pass


def gpu_sample():
    rows, err = nvidia_smi_query(["name", "utilization.gpu", "temperature.gpu", "memory.used", "memory.total", "power.draw"])
    if not rows:
        return None, err
    r = rows[0]
    return {
        "name": r.get("name"),
        "util": to_float(r.get("utilization.gpu"), 0),
        "temp": to_float(r.get("temperature.gpu"), 0),
        "used": to_float(r.get("memory.used"), 0),
        "total": to_float(r.get("memory.total"), 0),
        "power": to_float(r.get("power.draw"), 0),
    }, ""


def stress_params(config, context):
    cfg = dict(config["stress_test"])
    mode = (context or {}).get("mode", "hard")
    return cfg, mode


def gpu_cuda_stress(findings, metrics, cfg, mode):
    if not cfg.get("gpu_enabled", True):
        findings.append(Finding("INFO", "stress", "GPU stress disabled", "gpu_enabled is false in config.", "Enable gpu_enabled for CUDA stress."))
        return False

    print("      Probing Python environments for CUDA PyTorch...")
    cuda_py, probes = discover_cuda_python()
    metrics["gpu_cuda_python_probe_count"] = len(probes)

    if not cuda_py:
        findings.append(Finding(
            "OBSERVE",
            "stress",
            "NVIDIA GPU detected but CUDA PyTorch not found",
            "AutoCheck could not find any Python environment where torch.cuda.is_available() is true.",
            "Run: py -3.12 -c \"import sys, torch; print(sys.executable); print(torch.__version__); print(torch.cuda.is_available())\". Then run AutoCheck with that Python.",
            data={"python_probes": probes},
        ))
        return False

    print(f"      CUDA PyTorch selected: {cuda_py.get('python')}")
    print(f"      CUDA device: {cuda_py.get('device_name')} | torch {cuda_py.get('torch_version')} | CUDA {cuda_py.get('cuda_version')}")
    print(f"      Running sustained CUDA GPU stress ({mode.upper()})...")

    duration = int(cfg.get("gpu_compute_duration_seconds", 75))
    data = run_external_cuda_stress(cuda_py["command"], duration=duration, target_vram_percent=cfg.get("gpu_vram_target_percent", 90), stop_temp=cfg.get("gpu_stop_if_temp_c_over", 90), timeout=duration + 240, frag_duration=cfg.get("vram_fragmentation_duration_seconds", 45), frag_min_mb=cfg.get("vram_fragmentation_min_block_mb", 32), frag_max_mb=cfg.get("vram_fragmentation_max_block_mb", 512), util_target=cfg.get("gpu_util_target_percent", 90))

    if data.get("ok"):
        metrics["gpu_cuda_stress_peak_percent"] = data.get("peak_util", 0)
        metrics["gpu_cuda_stress_peak_temp_c"] = data.get("peak_temp", 0)
        metrics["gpu_cuda_stress_peak_vram_mb"] = data.get("peak_vram", 0)
        metrics["gpu_cuda_stress_peak_power_w"] = data.get("peak_power", 0)
        metrics["gpu_cuda_stress_samples"] = data.get("samples", 0)
        metrics["gpu_cuda_stress_iterations"] = data.get("iterations", 0)
        metrics["gpu_cuda_stress_approx_tflops"] = round(float(data.get("approx_tflops") or 0), 2)
        metrics["gpu_vram_fragmentation_blocks"] = data.get("fragmentation_blocks_remaining", 0)
        metrics["gpu_vram_fragmentation_alloc_attempt_mb"] = data.get("fragmentation_alloc_attempt_mb", 0)

        peak = float(data.get("peak_util") or 0)
        sev = "PASS" if peak >= 50 else "WARNING"
        title = "CUDA GPU stress completed" if peak >= 50 else "CUDA GPU stress ran but utilization stayed low"

        findings.append(Finding(
            sev,
            "stress",
            title,
            f"CUDA workload ran using {data.get('python')}. Device={data.get('device')}; torch={data.get('torch_version')}; matrix={data.get('matrix_n')}; iterations={data.get('iterations')}; approx {metrics['gpu_cuda_stress_approx_tflops']} TFLOPS; peak GPU {data.get('peak_util')}%, peak temp {data.get('peak_temp')} C, peak VRAM {data.get('peak_vram')} MB, peak power {data.get('peak_power')} W.",
            "If utilization is low, check NVIDIA Control Panel power mode, driver state, display/remote session limits, and whether another process is restricting GPU clocks.",
            data=data,
        ))
        return True

    findings.append(Finding(
        "WARNING",
        "stress",
        "CUDA GPU stress failed",
        f"CUDA PyTorch candidate was found at {cuda_py.get('python')}, but the stress workload failed: {data.get('error')}",
        "Check logs for CUDA backoff details. If OOM persists, lower gpu_vram_target_percent or close GPU-heavy apps.",
        data={"candidate": cuda_py, "stress_result": data, "python_probes": probes},
    ))
    return False


def run(config, args, context=None):
    cfg, mode = stress_params(config, context)
    duration = int(cfg["duration_seconds"])
    target = int(cfg["cpu_target_percent"])
    duty = max(0.10, min(0.99, target / 100.0))
    logical = psutil.cpu_count(logical=True) or 1
    physical = psutil.cpu_count(logical=False) or logical

    vm = psutil.virtual_memory()
    target_used = vm.total * (float(cfg["memory_target_percent_of_total"]) / 100.0)
    add_bytes = max(0, int(target_used - vm.used))
    add_bytes = min(add_bytes, int(vm.available * 0.75))
    add_mb = int(add_bytes / (1024 * 1024))

    if str(cfg.get("disk_test_mb", "auto")).lower() == "auto":
        disk_size = int(cfg.get("disk_test_min_mb", 1024))
        disk_size = min(max(disk_size, int(cfg.get("disk_test_min_mb", 1024))), int(cfg.get("disk_test_max_mb", 4096)))
    else:
        disk_size = int(cfg["disk_test_mb"])

    print(f"    Adaptive stress test: {duration}s ({mode.upper()})")
    print(f"      CPU target={target}% using multiprocessing on {physical}C/{logical}T")
    print("      Stress is intentionally heavy, but safety thresholds remain active unless hard_disable_safety=true")
    print(f"      RAM add target={add_mb/1024:.2f}GB")
    print(f"      Disk temp test={disk_size}MB")

    gpu, gpu_err = gpu_sample()
    if gpu:
        print(f"      NVIDIA GPU detected: {gpu['name']} ({gpu['total']/1024:.2f}GB VRAM)")
    else:
        print(f"      NVIDIA GPU telemetry unavailable: {gpu_err}")

    findings = []
    metrics = {}
    mem_blocks = []
    cpu_samples = []
    mem_samples = []
    gpu_samples = []

    # GPU first so it is not starved by CPU workers.
    if gpu:
        gpu_cuda_stress(findings, metrics, cfg, mode)

    stop = mp.Event()
    workers = []

    try:
        chunk = 64 * 1024 * 1024
        allocated = 0
        safety_disabled = bool(cfg.get("hard_disable_safety", False)) and mode == "hard"
        while allocated < add_bytes:
            n = min(chunk, add_bytes - allocated)
            mem_blocks.append(bytearray(n))
            allocated += n
            if not safety_disabled and psutil.virtual_memory().percent >= cfg["stop_if_memory_percent_over"]:
                break

        for _ in range(logical):
            p = mp.Process(target=cpu_burn_worker, args=(stop, duty))
            p.daemon = True
            p.start()
            workers.append(p)

        end = time.time() + duration
        while time.time() < end:
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            cpu_samples.append(cpu)
            mem_samples.append(mem)

            g, _ = gpu_sample()
            if g:
                gpu_samples.append(g)
                if not safety_disabled and g["temp"] >= cfg["gpu_stop_if_temp_c_over"]:
                    findings.append(Finding("WARNING", "stress", "GPU temperature threshold reached", f"GPU reached {g['temp']} C.", "Review GPU cooling if repeatable."))
                    break

            if not safety_disabled and mem >= cfg["stop_if_memory_percent_over"]:
                findings.append(Finding("WARNING", "stress", "Memory safety threshold reached", f"Memory reached {psutil.virtual_memory().percent:.1f}%.", "AutoCheck stopped stress early to avoid system instability."))
                break

        stop.set()
        for p in workers:
            p.join(timeout=3)
            if p.is_alive():
                p.terminate()
                p.join(timeout=2)

        metrics["cpu_stress_avg_percent"] = round(sum(cpu_samples) / len(cpu_samples), 2) if cpu_samples else 0
        metrics["cpu_stress_peak_percent"] = round(max(cpu_samples), 2) if cpu_samples else 0
        metrics["memory_stress_peak_percent"] = round(max(mem_samples), 2) if mem_samples else 0

        avg_cpu = metrics["cpu_stress_avg_percent"]
        peak_cpu = metrics["cpu_stress_peak_percent"]

        min_expected = max(35, target * 0.55)
        if avg_cpu < min_expected:
            sev = "WARNING"
            title = "CPU stress did not reach expected load"
            detail_extra = "This can happen if power plan, security software, VM limits, thermal throttling, or clock limits prevent CPU load."
        else:
            sev = "PASS"
            title = "CPU/RAM adaptive stress completed"
            detail_extra = "CPU load reached expected stress range."

        findings.append(Finding(
            sev,
            "stress",
            title,
            f"Completed {len(cpu_samples)}s of sampling. CPU target {target}% on {physical} core(s)/{logical} thread(s). RAM allocated {int(allocated/(1024*1024))}MB. Average CPU {avg_cpu}%, peak CPU {peak_cpu}%, peak memory {metrics['memory_stress_peak_percent']}%. {detail_extra}",
            "No action required unless the system felt unstable, loud, hot, or laggy during the test."
        ))

        write_mbps, read_mbps = disk_test(disk_size)
        metrics["disk_stress_write_mbps"] = round(write_mbps, 2)
        metrics["disk_stress_read_mbps"] = round(read_mbps, 2)
        findings.append(Finding(
            "PASS",
            "stress",
            "Disk write/read stress completed",
            f"Wrote {disk_size}MB at {write_mbps:.1f} MB/s and read {disk_size}MB at {read_mbps:.1f} MB/s using a temporary file that was deleted.",
            "No action required unless disk I/O was unusually slow or failed."
        ))

        if gpu_samples:
            metrics["gpu_stress_avg_percent"] = round(sum(g["util"] for g in gpu_samples) / len(gpu_samples), 2)
            metrics["gpu_stress_peak_percent"] = round(max(g["util"] for g in gpu_samples), 2)
            metrics["gpu_stress_peak_temp_c"] = round(max(g["temp"] for g in gpu_samples), 2)
            metrics["gpu_stress_peak_vram_mb"] = round(max(g["used"] for g in gpu_samples), 2)
            metrics["gpu_stress_peak_power_w"] = round(max(g["power"] for g in gpu_samples), 2)
        elif not gpu:
            findings.append(Finding("OBSERVE", "stress", "GPU telemetry unavailable", f"NVIDIA telemetry unavailable: {gpu_err}", "No action required if no NVIDIA GPU."))

    finally:
        stop.set()
        for p in workers:
            try:
                if p.is_alive():
                    p.terminate()
            except Exception:
                pass
        mem_blocks.clear()

    return findings, metrics
