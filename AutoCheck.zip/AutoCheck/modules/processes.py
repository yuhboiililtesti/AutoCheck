from collections import Counter
import psutil
from core.models import Finding


ALLOWLIST = {
    "svchost.exe", "msedgewebview2.exe", "opera.exe", "chrome.exe", "msedge.exe",
    "firefox.exe", "brave.exe", "steamwebhelper.exe", "Discord.exe", "Code.exe",
    "RuntimeBroker.exe", "conhost.exe", "OpenConsole.exe", "NVIDIA Overlay.exe",
}


def run(config, args, context=None):
    findings = []
    metrics = {}
    names = []
    proc_rows = []

    for p in psutil.process_iter(["pid", "name", "memory_percent"]):
        try:
            info = p.info
            name = info.get("name") or "unknown"
            names.append(name)
            proc_rows.append(info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    counts = Counter(names)
    metrics["process_count"] = len(names)
    metrics["unique_process_count"] = len(counts)

    findings.append(Finding("INFO", "processes", "Process count", f"{len(names)} processes observed; {len(counts)} unique process names.", "No action required unless the count is unexpectedly high."))

    top = sorted(proc_rows, key=lambda x: x.get("memory_percent") or 0, reverse=True)[:5]
    top_text = "; ".join(f"{p.get('name')}({p.get('pid')}) {p.get('memory_percent',0):.1f}%" for p in top)
    findings.append(Finding("INFO", "processes", "Top memory processes", top_text or "No data.", "Use this for review only. No action is taken automatically.", data={"top_memory": top}))

    threshold = config["thresholds"]["process_instance_warning"]
    for name, count in counts.items():
        if count >= threshold:
            if name in ALLOWLIST:
                findings.append(Finding("OBSERVE", "processes", f"High instance count: {name}", f"{name} is a known multi-process app/service; {count} instances is usually normal.", "Review only if you are seeing symptoms like slowness, high memory, crashes, or unknown windows."))
            else:
                findings.append(Finding("OBSERVE", "processes", f"High instance count: {name}", f"{name} has {count} running instances.", "Review only if unexpected. AutoCheck never kills processes."))
    return findings, metrics
