import importlib.util
import platform
import sys
from pathlib import Path
from core.models import Finding
from core.utils import which, powershell_path, is_windows


def run(config, args, context=None):
    findings = []
    metrics = {}

    required_tools = ["python", "pip", "powershell", "sc"]
    optional_tools = ["nvidia-smi"]

    for tool in required_tools + optional_tools:
        path = powershell_path() if tool == "powershell" else which(tool)
        if path:
            findings.append(Finding("PASS", "environment", f"Tool availability: {tool}", path, "No action required."))
        else:
            sev = "INFO" if tool in optional_tools else "OBSERVE"
            findings.append(Finding(sev, "environment", f"Tool availability: {tool}", "Not found in PATH.", "Install or add to PATH only if needed for deeper checks."))

    findings.append(Finding("INFO", "environment", "Python runtime", f"{platform.python_version()} at {sys.executable}", "Use the Python that has CUDA PyTorch installed for GPU stress."))
    findings.append(Finding("INFO", "environment", "Current user context", f"OS: {platform.system()}; Windows={is_windows()}", "No action required."))

    for mod in ["psutil", "yaml"]:
        available = importlib.util.find_spec(mod) is not None
        findings.append(Finding("PASS" if available else "WARNING", "environment", f"Python dependency: {mod}", "Available." if available else "Missing.", "Run pip install -r requirements.txt."))

    try:
        import clr  # noqa
        findings.append(Finding("INFO", "environment", "pythonnet availability", "pythonnet import succeeded.", "LibreHardwareMonitor integration can be attempted."))
    except Exception as exc:
        findings.append(Finding("INFO", "environment", "pythonnet availability", f"Unavailable: {exc}", "Only needed for optional LibreHardwareMonitor sensor support."))

    try:
        from core.torch_env import current_python_torch_status, discover_cuda_python
        torch_status, _ = current_python_torch_status()
        if torch_status.get("ok"):
            if torch_status.get("cuda_available"):
                findings.append(Finding("PASS", "environment", "PyTorch CUDA in active Python", f"torch {torch_status.get('torch_version')} CUDA={torch_status.get('cuda_version')} device={torch_status.get('device_name')} using {torch_status.get('python')}", "GPU stress can run in the current Python."))
            else:
                findings.append(Finding("OBSERVE", "environment", "PyTorch present but CUDA unavailable in active Python", f"torch {torch_status.get('torch_version')} using {torch_status.get('python')}", "Install a CUDA-enabled PyTorch build into the Python used to run AutoCheck."))
        else:
            cuda_py, probes = discover_cuda_python()
            if cuda_py:
                findings.append(Finding("INFO", "environment", "PyTorch CUDA found in alternate Python", f"CUDA PyTorch found at {cuda_py.get('python')} via command {' '.join(cuda_py.get('command', []))}. Active Python lacks torch: {torch_status.get('error')}", "AutoCheck stress can use this alternate Python for GPU stress."))
            else:
                findings.append(Finding("OBSERVE", "environment", "PyTorch unavailable in active Python", f"Active Python {torch_status.get('python')} cannot import torch: {torch_status.get('error')}", "Install CUDA-enabled PyTorch into the active Python or run AutoCheck with the Python where torch is installed.", data={"python_probes": probes[:5]}))
    except Exception as exc:
        findings.append(Finding("INFO", "environment", "PyTorch environment probe failed", str(exc), "GPU stress will fall back to nvidia-smi telemetry only."))

    dll = Path("external/LibreHardwareMonitor/LibreHardwareMonitorLib.dll")
    findings.append(Finding("INFO", "environment", "LibreHardwareMonitor DLL", "Present." if dll.exists() else "Not present.", "Place LibreHardwareMonitorLib.dll there for optional sensor support."))

    metrics["environment_pass_count"] = sum(1 for f in findings if f.severity == "PASS")
    return findings, metrics
