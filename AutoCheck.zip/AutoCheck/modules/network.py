import socket
import psutil
from core.models import Finding


def run(config, args, context=None):
    findings = []
    metrics = {}
    host = socket.gethostname()
    findings.append(Finding("INFO", "network", "Hostname", host, "No action required unless this is not the expected machine name."))

    stats = psutil.net_if_stats()
    active = [name for name, st in stats.items() if st.isup]
    metrics["network_active_interface_count"] = len(active)
    findings.append(Finding("PASS" if active else "WARNING", "network", "Active network interfaces", ", ".join(active) if active else "None.", "Check Wi-Fi/Ethernet state if no interface is active."))

    try:
        conns = psutil.net_connections(kind="inet")
        listen = [c for c in conns if c.status == psutil.CONN_LISTEN]
        metrics["network_listening_socket_count"] = len(listen)
        findings.append(Finding("INFO", "network", "Listening network sockets", f"{len(listen)} listening socket(s) detected.", "Review listening services if you are hardening the system."))
    except Exception as exc:
        findings.append(Finding("INFO", "network", "Listening network sockets", f"Unavailable: {exc}", "Permission-limited result."))
    return findings, metrics
