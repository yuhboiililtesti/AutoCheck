from core.models import Finding
from core.utils import is_windows, ps_json


def _query(title, script):
    return ps_json(script, timeout=60)


def run(config, args, context=None):
    findings = []
    metrics = {}
    if not is_windows():
        return [Finding("OBSERVE", "hardware_deep", "Deep hardware unavailable", "This module requires Windows CIM/WMI.", "Run on Windows.")], {}

    queries = [
        ("Motherboard profile", "Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product,SerialNumber,Version"),
        ("BIOS profile", "Get-CimInstance Win32_BIOS | Select-Object Manufacturer,SMBIOSBIOSVersion,ReleaseDate,SerialNumber"),
        ("RAM modules", "Get-CimInstance Win32_PhysicalMemory | Select-Object Manufacturer,PartNumber,Speed,ConfiguredClockSpeed,Capacity,DeviceLocator,BankLabel"),
        ("GPU adapters", "Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,AdapterRAM,VideoModeDescription,PNPDeviceID"),
        ("Audio devices", "Get-CimInstance Win32_SoundDevice | Select-Object Name,Manufacturer,Status,PNPDeviceID"),
        ("USB controllers", "Get-CimInstance Win32_USBController | Select-Object Name,Manufacturer,Status"),
        ("Network/PCI adapters", "Get-CimInstance Win32_PnPEntity | Where-Object {$_.PNPClass -eq 'Net' -or $_.PNPClass -eq 'System'} | Select-Object Name,PNPClass,Status,ConfigManagerErrorCode"),
    ]

    for title, script in queries:
        data, err, code = _query(title, script)
        findings.append(Finding("INFO" if data else "INFO", "hardware_deep", title, "Query completed successfully." if data else f"Unavailable: {err}", "Review only if related symptoms exist.", data={title: data} if data else {}))

    pnp, err, code = ps_json("Get-CimInstance Win32_PnPEntity | Where-Object {$_.ConfigManagerErrorCode -ne 0} | Select-Object Name,PNPClass,Status,ConfigManagerErrorCode")
    if pnp:
        items = pnp if isinstance(pnp, list) else [pnp]
        metrics["pnp_problem_device_count"] = len(items)
        for item in items:
            code = item.get("ConfigManagerErrorCode")
            sev = "INFO" if code == 22 else "OBSERVE"
            findings.append(Finding(sev, "hardware_deep", "PnP problem/disabled device", f"{item.get('Name')} class={item.get('PNPClass')} ConfigManagerErrorCode {code}.", "Code 22 is usually a disabled device, not a fault unless it is an active required adapter.", data=item))
    else:
        findings.append(Finding("PASS", "hardware_deep", "PnP problem devices", "No nonzero ConfigManagerErrorCode devices were returned.", "No action required."))

    return findings, metrics
