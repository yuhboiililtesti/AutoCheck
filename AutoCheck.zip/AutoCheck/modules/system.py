import platform
import time
import psutil
from core.models import Finding
from core.utils import gb, is_windows, ps_json


def run(config, args, context=None):
    t = config["thresholds"]
    findings = []
    metrics = {}

    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    boot = psutil.boot_time()
    uptime_days = int((time.time() - boot) / 86400)

    metrics.update({
        "cpu_percent": cpu,
        "memory_percent": mem.percent,
        "memory_used_gb": gb(mem.used),
        "memory_total_gb": gb(mem.total),
        "uptime_days": uptime_days,
    })

    sev = "CRITICAL" if cpu >= t["cpu_critical"] else "WARNING" if cpu >= t["cpu_warning"] else "PASS"
    findings.append(Finding(sev, "system", "CPU utilization", f"Current CPU usage is {cpu:.1f}%.", "Investigate high-load processes if this remains high while idle."))

    sev = "CRITICAL" if mem.percent >= t["memory_critical"] else "WARNING" if mem.percent >= t["memory_warning"] else "PASS"
    findings.append(Finding(sev, "system", "Memory utilization", f"Current memory usage is {mem.percent:.1f}% ({gb(mem.used)} GB used of {gb(mem.total)} GB).", "Review startup apps, browser tabs, game launchers, overlays, and background utilities if memory remains high."))

    if uptime_days >= t["boot_age_warning_days"]:
        sev = "OBSERVE"
    else:
        sev = "PASS"
    findings.append(Finding(sev, "system", "System uptime", f"Last boot was {time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(boot))} ({uptime_days} day(s) ago).", "Restart manually during a convenient maintenance window only if updates or odd behavior require it."))

    os_detail = platform.platform()
    if is_windows():
        data, err, code = ps_json("Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture")
        if data:
            caption = data.get("Caption", "Windows")
            build = int(data.get("BuildNumber") or 0)
            if build >= 22000 and "Windows 10" in caption:
                caption = caption.replace("Windows 10", "Windows 11")
            os_detail = f"{caption} {data.get('Version')} on {data.get('OSArchitecture')}"
            metrics["windows_build"] = build
    findings.append(Finding("INFO", "system", "Operating system", os_detail, "No action required unless the OS/build is not what you expect."))
    return findings, metrics
