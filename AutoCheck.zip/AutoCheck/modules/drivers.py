from core.models import Finding
from core.utils import is_windows, run_cmd, ps_json, nvidia_smi_query


def run(config, args, context=None):
    findings = []
    metrics = {}
    if is_windows():
        out, err, code = run_cmd("driverquery /fo csv", timeout=60)
        if code == 0 and out:
            count = max(0, len(out.splitlines()) - 1)
            metrics["driverquery_count"] = count
            findings.append(Finding("INFO", "drivers", "Installed drivers", f"{count} driver row(s) reported by driverquery.", "Review Device Manager only if hardware or stability issues exist.", data={"driverquery_excerpt": out[:4000]}))
        else:
            findings.append(Finding("INFO", "drivers", "Installed drivers", f"driverquery unavailable: {err or out}", "Permission/PATH limited result."))

        signed, err, code = ps_json("Get-CimInstance Win32_PnPSignedDriver | Select-Object -First 200 DeviceName,DriverVersion,Manufacturer,IsSigned")
        if signed:
            items = signed if isinstance(signed, list) else [signed]
            unsigned = [x for x in items if x.get("IsSigned") is False]
            findings.append(Finding("OBSERVE" if unsigned else "PASS", "drivers", "Signed driver sample", f"{len(unsigned)} unsigned driver(s) found in first {len(items)} sampled drivers.", "Review unsigned drivers only if instability/security concerns exist.", data={"unsigned_sample": unsigned[:20]}))

    rows, err = nvidia_smi_query(["name", "driver_version"])
    findings.append(Finding("INFO", "drivers", "GPU driver version", f"{rows[0].get('name')} driver {rows[0].get('driver_version')}" if rows else f"NVIDIA telemetry unavailable: {err}", "Review vendor updates only if GPU problems exist."))
    return findings, metrics
