import re
import socket
import statistics
import time
from core.models import Finding
from core.utils import is_windows, ps_json, run_cmd, tcp_connect


def dns_latency():
    start = time.perf_counter()
    socket.getaddrinfo("example.com", 80)
    return (time.perf_counter() - start) * 1000


def ping(host):
    cmd = f"ping -n 4 {host}" if is_windows() else f"ping -c 4 {host}"
    out, err, code = run_cmd(cmd, timeout=20)
    text = out + "\n" + err
    avg = None
    loss = None
    m = re.search(r"Average = (\d+)ms", text)
    if m:
        avg = float(m.group(1))
    m = re.search(r"(\d+)% loss", text)
    if m:
        loss = float(m.group(1))
    nums = [float(x) for x in re.findall(r"time[=<](\d+(?:\.\d+)?)", text)]
    if avg is None and nums:
        avg = statistics.mean(nums)
    return avg, loss, text[:1000]


def run(config, args, context=None):
    findings = []
    metrics = {}
    t = config["thresholds"]

    try:
        dns = dns_latency()
        metrics["network_dns_latency_ms"] = round(dns, 2)
        findings.append(Finding("WARNING" if dns >= t["dns_warning_ms"] else "PASS", "network_deep", "DNS resolution latency", f"example.com resolved in {dns:.1f} ms.", "Review DNS servers if repeatedly high."))
    except Exception as exc:
        findings.append(Finding("WARNING", "network_deep", "DNS resolution latency", f"Failed: {exc}", "Check DNS/network connectivity."))

    pings = []
    losses = []
    for host in ["1.1.1.1", "8.8.8.8"]:
        avg, loss, raw = ping(host)
        if avg is not None:
            pings.append(avg)
        if loss is not None:
            losses.append(loss)
        findings.append(Finding("INFO", "network_deep", f"Ping {host}", f"Average={avg}; Loss={loss}.", "Review only if latency/loss exceeds threshold.", data={"raw": raw}))

    if pings:
        avg = statistics.mean(pings)
        metrics["network_ping_avg_ms"] = round(avg, 2)
        findings.append(Finding("WARNING" if avg >= t["ping_warning_ms"] else "PASS", "network_deep", "Average ping latency", f"{avg:.1f} ms.", "Review network route/Wi-Fi/ISP if high."))
    if losses:
        loss = max(losses)
        metrics["network_packet_loss_percent"] = loss
        findings.append(Finding("WARNING" if loss else "PASS", "network_deep", "Packet loss", f"{loss:.1f}% max observed packet loss.", "Packet loss should be investigated if repeatable."))

    if is_windows():
        for title, script in [
            ("Adapter details", "Get-NetAdapter | Select-Object Name,Status,LinkSpeed,MacAddress,InterfaceDescription,DriverVersion"),
            ("DNS servers", "Get-DnsClientServerAddress | Select-Object InterfaceAlias,AddressFamily,ServerAddresses"),
            ("Default routes", "Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Select-Object InterfaceAlias,NextHop,RouteMetric"),
            ("Network profile", "Get-NetConnectionProfile | Select-Object Name,InterfaceAlias,NetworkCategory,IPv4Connectivity,IPv6Connectivity"),
        ]:
            data, err, code = ps_json(script)
            findings.append(Finding("INFO", "network_deep", title, "Readable." if data else f"Unavailable: {err}", "Review only if network symptoms exist.", data={title: data} if data else {}))

    for host, port in [("1.1.1.1", 53), ("1.1.1.1", 443), ("8.8.8.8", 443)]:
        ok = tcp_connect(host, port)
        findings.append(Finding("PASS" if ok else "OBSERVE", "network_deep", f"TCP connectivity {host}:{port}", "Connection succeeded." if ok else "Connection failed.", "Review firewall/router/ISP only if repeated."))
    return findings, metrics
