from core.models import Finding
from core.utils import is_windows, ps_json


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "installed_updates", "Installed updates unavailable", "This module requires Windows.", "Run on Windows.")], {}
    data, err, code = ps_json("Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object HotFixID,Description,InstalledOn,InstalledBy")
    if not data:
        return [Finding("INFO", "installed_updates", "Installed updates", f"Unavailable: {err}", "No online update check required.")], {}
    items = data if isinstance(data, list) else [data]
    return [Finding("INFO", "installed_updates", "Installed updates", f"{len(items)} hotfix row(s) found. Latest: {items[0].get('HotFixID')}", "Review only if update history appears stale.", data={"latest": items[0], "sample": items[:20]})], {"installed_hotfix_count": len(items)}
