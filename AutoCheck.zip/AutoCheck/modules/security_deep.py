from core.models import Finding
from core.utils import is_windows, ps_json, run_ps, is_admin


def _as_bool(value):
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"true", "1", "yes"}:
        return True
    if text in {"false", "0", "no"}:
        return False
    return None


def _normalize_tpm(raw, source):
    if not raw:
        return None
    if isinstance(raw, list):
        raw = raw[0] if raw else None
    if not isinstance(raw, dict):
        return None
    normalized = {
        "TpmPresent": _as_bool(raw.get("TpmPresent") if "TpmPresent" in raw else raw.get("IsEnabled_InitialValue")),
        "TpmReady": _as_bool(raw.get("TpmReady") if "TpmReady" in raw else raw.get("IsActivated_InitialValue")),
        "TpmEnabled": _as_bool(raw.get("TpmEnabled") if "TpmEnabled" in raw else raw.get("IsEnabled_InitialValue")),
        "TpmActivated": _as_bool(raw.get("TpmActivated") if "TpmActivated" in raw else raw.get("IsActivated_InitialValue")),
        "Source": source,
    }
    return normalized


def _query_tpm():
    attempts = []

    data, err, code = ps_json("Get-Tpm | Select-Object TpmPresent,TpmReady,TpmEnabled,TpmActivated", timeout=30)
    attempts.append({"source": "Get-Tpm", "code": code, "error": err, "data": data})
    tpm = _normalize_tpm(data, "Get-Tpm")
    if tpm and any(v is not None for k, v in tpm.items() if k != "Source"):
        return tpm, attempts

    data, err, code = ps_json("Get-CimInstance -Namespace 'Root\\CIMV2\\Security\\MicrosoftTpm' -ClassName Win32_Tpm | Select-Object IsEnabled_InitialValue,IsActivated_InitialValue,IsOwned_InitialValue", timeout=30)
    attempts.append({"source": "Win32_Tpm", "code": code, "error": err, "data": data})
    tpm = _normalize_tpm(data, "Win32_Tpm")
    if tpm and any(v is not None for k, v in tpm.items() if k != "Source"):
        return tpm, attempts

    out, err, code = run_ps("tpm.msc", timeout=5)
    attempts.append({"source": "tpm.msc_probe", "code": code, "error": err, "data": out[:300] if out else None})
    return {"TpmPresent": None, "TpmReady": None, "TpmEnabled": None, "TpmActivated": None, "Source": "unresolved"}, attempts


def run(config, args, context=None):
    findings = []
    metrics = {"is_admin": 1 if is_admin() else 0}
    if not is_windows():
        return [Finding("OBSERVE", "security_deep", "Deep security unavailable", "This module requires Windows.", "Run on Windows.")], metrics

    admin = is_admin()
    findings.append(Finding("INFO", "security_deep", "Local admin check", f"Running as administrator: {admin}", "Some checks are more detailed when elevated."))
    if not admin:
        findings.append(Finding("OBSERVE", "security_deep", "Permission-limited scan context", "AutoCheck is not running as administrator, so TPM, BitLocker, device, event, and firmware checks may return partial data.", "For maximum diagnostic accuracy, rerun from an elevated terminal. This is not a confirmed system fault."))

    tpm, attempts = _query_tpm()
    metrics["tpm_query_resolved"] = 1 if any(v is not None for k, v in tpm.items() if k not in {"Source"}) else 0
    if metrics["tpm_query_resolved"]:
        metrics["tpm_present"] = 1 if tpm.get("TpmPresent") else 0
        metrics["tpm_ready"] = 1 if tpm.get("TpmReady") else 0
        sev = "PASS" if tpm.get("TpmPresent") and tpm.get("TpmReady") else "OBSERVE"
        detail = f"Present={tpm.get('TpmPresent')}; Ready={tpm.get('TpmReady')}; Enabled={tpm.get('TpmEnabled')}; Activated={tpm.get('TpmActivated')}; Source={tpm.get('Source')}"
        suggestion = "Review firmware TPM settings only if TPM is expected but not present/ready."
    else:
        sev = "OBSERVE"
        detail = "TPM state could not be resolved after Get-Tpm and Win32_Tpm fallback queries. This is an uncertain/limited signal, not a confirmed TPM failure."
        suggestion = "Rerun as administrator and verify firmware TPM/AMD fTPM is enabled if Windows security features require TPM."
    findings.append(Finding(sev, "security_deep", "TPM status", detail, suggestion, data={"tpm": tpm, "attempts": attempts}))

    out, err, code = run_ps("Confirm-SecureBootUEFI", timeout=20)
    findings.append(Finding("PASS" if code == 0 and "true" in out.lower() else "INFO", "security_deep", "Secure Boot", out if out else err, "SecureBoot query failure is often firmware/permission/platform-limited."))

    bl, err, code = ps_json("Get-BitLockerVolume | Select-Object MountPoint,ProtectionStatus,VolumeStatus,EncryptionPercentage", timeout=30)
    findings.append(Finding("INFO", "security_deep", "BitLocker status", "Readable." if bl else f"Unavailable: {err}", "BitLocker CIM access denied is not counted as a real warning.", data={"bitlocker": bl} if bl else {}))

    uac, err, code = ps_json("Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System' | Select-Object EnableLUA,ConsentPromptBehaviorAdmin", timeout=30)
    if uac:
        findings.append(Finding("PASS" if int(uac.get("EnableLUA", 0)) == 1 else "WARNING", "security_deep", "UAC status", f"EnableLUA={uac.get('EnableLUA')}", "Enable UAC unless intentionally controlled by policy.", data=uac))
    return findings, metrics
