import psutil
from core.utils import nvidia_smi_query


def run_monitor(config=None):
    print("AutoCheck live monitor. Ctrl+C to exit.")
    while True:
        try:
            cpu = psutil.cpu_percent(interval=1)
            ram = psutil.virtual_memory().percent
            disk = "n/a"
            for mount in ["C:\\", "/"]:
                try:
                    disk = f"{psutil.disk_usage(mount).percent:.1f}%"
                    break
                except Exception:
                    pass
            net = psutil.net_io_counters()
            gpu_text = "GPU n/a"
            rows, _ = nvidia_smi_query(["utilization.gpu", "memory.used", "memory.total", "temperature.gpu", "power.draw"], timeout=3)
            if rows:
                r = rows[0]
                gpu_text = f"GPU {r.get('utilization.gpu')}% | VRAM {r.get('memory.used')}/{r.get('memory.total')} MB | Temp {r.get('temperature.gpu')} C | Power {r.get('power.draw')} W"
            print(f"CPU {cpu:5.1f}% | RAM {ram:5.1f}% | Disk C {disk} | Network sent {net.bytes_sent} recv {net.bytes_recv} | {gpu_text}")
        except KeyboardInterrupt:
            print("\nMonitor stopped safely.")
            break
