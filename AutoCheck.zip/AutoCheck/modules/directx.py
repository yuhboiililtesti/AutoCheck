import os
from pathlib import Path
from core.models import Finding
from core.utils import is_windows, run_cmd, temp_file_path


def read_robust(path):
    raw = Path(path).read_bytes()
    for enc in ["utf-16", "utf-8-sig", "utf-8", "latin-1"]:
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return raw.decode("utf-8", errors="replace")


def extract(text):
    labels = ["DirectX Version", "Card name", "Driver Version", "Driver Model", "Display Memory", "Dedicated Memory", "Current Mode"]
    found = {}
    for line in text.splitlines():
        s = line.strip()
        for label in labels:
            if s.lower().startswith(label.lower() + ":"):
                found[label] = s.split(":", 1)[1].strip()
    return found


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "directx", "DirectX unavailable", "This module requires Windows dxdiag.", "Run on Windows.")], {}

    path = temp_file_path(prefix="autocheck_dxdiag_", suffix=".txt")
    try:
        out, err, code = run_cmd(f'dxdiag /t "{path}"', timeout=120)
        if not os.path.exists(path):
            return [Finding("INFO", "directx", "dxdiag", f"Unavailable: {err or out}", "No confirmed graphics fault.")], {}
        text = read_robust(path)
        fields = extract(text)
        return [Finding("INFO" if fields else "OBSERVE", "directx", "DirectX/display diagnostics", "dxdiag output parsed successfully." if fields else "dxdiag ran but expected fields were not found.", "Review only if display/GPU symptoms exist.", data=fields)], {}
    finally:
        try:
            os.remove(path)
        except Exception:
            pass
