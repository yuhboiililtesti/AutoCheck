from core.models import Finding
from core.utils import is_windows, ps_json


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "startup", "Startup entries unavailable", "This module requires Windows.", "Run on Windows.")], {}
    data, err, code = ps_json("Get-CimInstance Win32_StartupCommand | Select-Object Name,Command,Location,User")
    if not data:
        return [Finding("INFO", "startup", "Startup entries", f"Unavailable or none: {err}", "Review startup manually only if boot feels slow.")], {}
    items = data if isinstance(data, list) else [data]
    sev = "OBSERVE" if len(items) >= 20 else "INFO"
    return [Finding(sev, "startup", "Startup entries", f"{len(items)} startup command(s) detected.", "Review startup items manually if boot feels slow or background apps are excessive.", data={"items": items[:50]})], {"startup_entry_count": len(items)}
