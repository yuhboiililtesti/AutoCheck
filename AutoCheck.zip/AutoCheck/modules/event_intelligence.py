import yaml
from pathlib import Path
from collections import Counter
from core.models import Finding
from core.utils import is_windows, ps_json


def load_rules():
    p = Path("data/event_rules.yaml")
    if not p.exists():
        return {}
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _items(data):
    return data if isinstance(data, list) else ([data] if data else [])


def _event_digest(items):
    counts = Counter()
    examples = {}
    for ev in items:
        provider = str(ev.get("ProviderName", "Unknown"))
        eid = str(ev.get("Id", "Unknown"))
        log = str(ev.get("LogName", "Unknown"))
        level = str(ev.get("LevelDisplayName", "Unknown"))
        key = (log, provider, eid, level)
        counts[key] += 1
        examples.setdefault(key, ev)
    digest = []
    for (log, provider, eid, level), count in counts.most_common(10):
        ev = examples[(log, provider, eid, level)]
        msg = str(ev.get("Message", "")).replace("\r", " ").replace("\n", " ").strip()
        digest.append({"log": log, "provider": provider, "id": eid, "level": level, "count": count, "message_preview": msg[:500]})
    return digest


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "event_intelligence", "Event intelligence unavailable", "This module requires Windows.", "Run on Windows.")], {}

    rules = load_rules().get("known_events", {})
    data, err, code = ps_json("$since=(Get-Date).AddDays(-1); Get-WinEvent -FilterHashtable @{LogName='System','Application'; Level=1,2,3; StartTime=$since} -ErrorAction SilentlyContinue | Select-Object -First 200 TimeCreated,LogName,ProviderName,Id,LevelDisplayName,Message", timeout=120)
    if not data:
        return [Finding("INFO", "event_intelligence", "Event intelligence sample", f"Unavailable or empty: {err}", "No confirmed event issue.")], {}

    items = _items(data)
    findings = []
    storage = gpu = whea = app_crash = 0
    matched = 0
    digest = _event_digest(items)

    for ev in items:
        provider = str(ev.get("ProviderName", ""))
        eid = str(ev.get("Id", ""))
        key = f"{provider}:{eid}"
        msg = str(ev.get("Message", ""))
        rule = rules.get(key)
        if rule:
            matched += 1
            findings.append(Finding(rule.get("severity", "OBSERVE"), "event_intelligence", f"{provider} Event {eid}", f"Cause: {rule.get('cause')}. Impact: {rule.get('impact')}.", rule.get("recommendation", "Review if repeated."), data={"event": ev}))
        text = f"{provider} {eid} {msg}".lower()
        if any(x in text for x in ["disk", "ntfs", "storahci"]):
            storage += 1
        if "nvlddmkm" in text:
            gpu += 1
        if "whea" in text:
            whea += 1
        if provider.lower() in {"application error", "windows error reporting"} or "faulting application" in text:
            app_crash += 1

    if storage:
        findings.append(Finding("CRITICAL" if storage >= 5 else "WARNING", "event_intelligence", "Storage event pattern", f"{storage} storage-related event(s) found.", "Back up important data and inspect disk health.", data={"event_digest": digest}))
    if gpu:
        findings.append(Finding("CRITICAL" if gpu >= 5 else "WARNING", "event_intelligence", "NVIDIA driver event pattern", f"{gpu} nvlddmkm event(s) found.", "Review GPU driver, thermals, and stability.", data={"event_digest": digest}))
    if whea:
        findings.append(Finding("CRITICAL" if whea >= 3 else "WARNING", "event_intelligence", "WHEA hardware error pattern", f"{whea} WHEA event(s) found.", "Review hardware stability.", data={"event_digest": digest}))
    if app_crash:
        top = digest[0] if digest else {}
        findings.append(Finding("OBSERVE", "event_intelligence", "Application crash/error context", f"{app_crash} application crash/error signal(s) detected in the event sample. Top grouped source: {top.get('provider','Unknown')} Event {top.get('id','Unknown')} ({top.get('count',1)}x).", "Review full logs only if this matches crashes, freezes, or app instability.", data={"event_digest": digest}))

    if not findings:
        findings.append(Finding("PASS", "event_intelligence", "No high-risk event patterns detected", "No Disk/Ntfs/storahci/nvlddmkm/WHEA pattern detected in sample.", "No action required.", data={"event_digest": digest}))
    return findings, {"event_intelligence_sample_count": len(items), "event_intelligence_rule_matches": matched, "event_app_crash_signals": app_crash, "event_storage_signals": storage, "event_gpu_signals": gpu, "event_whea_signals": whea}
