from collections import Counter
from core.models import Finding
from core.utils import is_windows, ps_json


def _items(data):
    return data if isinstance(data, list) else ([data] if data else [])


def _summarize_events(items):
    counts = Counter()
    examples = {}
    for ev in items:
        provider = str(ev.get("ProviderName", "Unknown"))
        eid = str(ev.get("Id", "Unknown"))
        level = str(ev.get("LevelDisplayName", "Unknown"))
        key = (provider, eid, level)
        counts[key] += 1
        examples.setdefault(key, ev)
    summary = []
    for (provider, eid, level), count in counts.most_common(8):
        ev = examples[(provider, eid, level)]
        msg = str(ev.get("Message", "")).replace("\r", " ").replace("\n", " ").strip()
        summary.append({
            "provider": provider,
            "id": eid,
            "level": level,
            "count": count,
            "time": str(ev.get("TimeCreated", "")),
            "message_preview": msg[:500],
        })
    return summary


def run(config, args, context=None):
    findings = []
    metrics = {}
    if not is_windows():
        return [Finding("OBSERVE", "windows_events", "Windows events unavailable", "This module requires Windows.", "Run on Windows.")], {}

    threshold = config["thresholds"]["event_warning_count"]
    for log in ["System", "Application"]:
        script = f"$since=(Get-Date).AddDays(-1); Get-WinEvent -FilterHashtable @{{LogName='{log}'; Level=1,2; StartTime=$since}} -ErrorAction SilentlyContinue | Select-Object -First 100 TimeCreated,ProviderName,Id,LevelDisplayName,Message"
        data, err, code = ps_json(script, timeout=90)
        items = _items(data)
        count = len(items)
        metrics[f"{log.lower()}_critical_error_events_24h"] = count
        sev = "WARNING" if count >= threshold else "PASS"
        if not data and err:
            findings.append(Finding("OBSERVE", "windows_events", f"{log} event scan limited", err, "Run as administrator if event access is restricted."))
        else:
            summary = _summarize_events(items)
            findings.append(Finding(sev, "windows_events", f"{log} critical/error events", f"{count} event(s) in last 24h.", "Review repeated hardware/storage/driver events. Common DCOM noise is reduced by event intelligence.", data={"sample": items[:20], "summary": summary}))
            if count and log == "Application":
                top = summary[0] if summary else {}
                detail = f"{count} Application critical/error event(s) in the last 24h. Top source: {top.get('provider','Unknown')} Event {top.get('id','Unknown')} ({top.get('count',1)}x)."
                findings.append(Finding("OBSERVE", "windows_events", "Application event context", detail, "Open the full log for provider/message previews; investigate only if crashes match symptoms.", data={"event_summary": summary}))
            if count and log == "System":
                top = summary[0] if summary else {}
                detail = f"{count} System critical/error event(s) in the last 24h. Top source: {top.get('provider','Unknown')} Event {top.get('id','Unknown')} ({top.get('count',1)}x)."
                findings.append(Finding("OBSERVE", "windows_events", "System event context", detail, "Review if repeated hardware, storage, driver, or WHEA providers appear.", data={"event_summary": summary}))
    return findings, metrics
