from core.models import Finding
from core.utils import is_windows, ps_json


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "services", "Windows services unavailable", "This module requires Windows.", "Run on Windows.")], {}
    data, err, code = ps_json("Get-CimInstance Win32_Service | Select-Object Name,DisplayName,State,StartMode,Status")
    if not data:
        return [Finding("INFO", "services", "Windows services summary", f"Unavailable: {err}", "Permission-limited result; not a confirmed fault.")], {}
    items = data if isinstance(data, list) else [data]
    running = sum(1 for s in items if str(s.get("State")).lower() == "running")
    stopped = sum(1 for s in items if str(s.get("State")).lower() == "stopped")
    auto_stopped = sum(1 for s in items if str(s.get("StartMode")).lower() == "auto" and str(s.get("State")).lower() == "stopped")
    return [Finding("INFO", "services", "Windows services summary", f"{len(items)} services scanned; {running} running; {stopped} stopped; {auto_stopped} auto-start stopped.", "Stopped services are not automatically bad. Review only if something you need is not working.")], {"service_count": len(items), "services_running": running, "services_stopped": stopped, "services_auto_stopped": auto_stopped}
