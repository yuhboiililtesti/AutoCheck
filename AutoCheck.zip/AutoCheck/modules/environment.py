# Compatibility alias for older AutoCheck configs. The full module is autocheck_selftest.py.
from modules.autocheck_selftest import run
