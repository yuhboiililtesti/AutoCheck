import platform
import psutil
from core.models import Finding
from core.utils import is_windows, ps_json, nvidia_smi_query, to_float, gb


def run(config, args, context=None):
    findings = []
    metrics = {}

    cpu_name = platform.processor() or "Unknown CPU"
    cpu_data = None
    if is_windows():
        cpu_data, err, code = ps_json("Get-CimInstance Win32_Processor | Select-Object -First 1 Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed")
        if cpu_data:
            cpu_name = cpu_data.get("Name") or cpu_name

    physical = psutil.cpu_count(logical=False) or 0
    logical = psutil.cpu_count(logical=True) or 0
    freq = psutil.cpu_freq()
    cur = freq.current if freq else 0
    maxf = freq.max if freq else 0
    metrics.update({"cpu_physical_cores": physical, "cpu_logical_threads": logical, "cpu_current_mhz": cur, "cpu_max_mhz": maxf})
    findings.append(Finding("INFO", "hardware", "CPU profile", f"{cpu_name}; {physical} physical core(s), {logical} logical thread(s); current {cur:.1f} MHz, max {maxf:.1f} MHz.", "Hard stress test scales CPU workers and load target to this CPU.", data=cpu_data or {}))

    mem = psutil.virtual_memory()
    metrics.update({"memory_total_gb": gb(mem.total), "memory_available_gb": gb(mem.available)})
    findings.append(Finding("INFO", "hardware", "Memory profile", f"{gb(mem.total)} GB total; {gb(mem.available)} GB available; {mem.percent:.1f}% currently used.", "Hard stress test sizes RAM pressure from total RAM and currently available RAM."))

    rows, err = nvidia_smi_query(["name", "driver_version", "memory.total", "memory.used", "utilization.gpu", "temperature.gpu", "power.draw"])
    if rows:
        for idx, gpu in enumerate(rows):
            total = to_float(gpu.get("memory.total"), 0)
            used = to_float(gpu.get("memory.used"), 0)
            metrics["gpu_vram_total_mb"] = total
            metrics["gpu_vram_used_mb"] = used
            metrics["gpu_util_percent"] = to_float(gpu.get("utilization.gpu"), 0)
            metrics["gpu_temp_c"] = to_float(gpu.get("temperature.gpu"), 0)
            metrics["gpu_power_w"] = to_float(gpu.get("power.draw"), 0)
            findings.append(Finding("INFO", "hardware", f"NVIDIA GPU profile #{idx}", f"{gpu.get('name')} with {total/1024:.2f} GB VRAM; driver {gpu.get('driver_version')}.", "GPU stress adapts to detected VRAM when CUDA PyTorch is installed.", data=gpu))
    else:
        vc, verr, code = ps_json("Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,AdapterRAM,VideoProcessor") if is_windows() else (None, "", 0)
        findings.append(Finding("INFO", "hardware", "GPU profile", "nvidia-smi unavailable; WMI fallback captured GPU data." if vc else f"GPU telemetry unavailable: {err or verr}", "No action required if no NVIDIA GPU.", data={"wmi_video": vc} if vc else {}))

    return findings, metrics
