# Compatibility alias for older AutoCheck configs. The full module is storage.py.
from modules.storage import run
