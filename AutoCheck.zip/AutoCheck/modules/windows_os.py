import locale
import os
import time
from core.models import Finding
from core.utils import is_windows, ps_json, run_ps


def run(config, args, context=None):
    findings = []
    metrics = {}
    if not is_windows():
        return [Finding("OBSERVE", "windows_os", "Windows OS checks unavailable", "This module requires Windows.", "Run on Windows.")], {}

    osinfo, err, code = ps_json("Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture,InstallDate,WindowsDirectory,SystemDirectory,SystemDrive")
    if osinfo:
        build = int(osinfo.get("BuildNumber") or 0)
        caption = osinfo.get("Caption", "Windows")
        if build >= 22000 and "Windows 10" in caption:
            caption = caption.replace("Windows 10", "Windows 11")
        findings.append(Finding("INFO", "windows_os", "Windows edition/build", f"{caption}; version {osinfo.get('Version')}; build {build}; architecture {osinfo.get('OSArchitecture')}.", "No action required.", data=osinfo))
        metrics["windows_build"] = build
    else:
        findings.append(Finding("INFO", "windows_os", "Windows edition/build unavailable", err or "No data.", "Permission-limited result; not a confirmed fault."))

    reboot, err, code = ps_json("""
$paths=@(
'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing\\RebootPending',
'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update\\RebootRequired'
)
[ordered]@{CBS=(Test-Path $paths[0]); WindowsUpdate=(Test-Path $paths[1])}
""")
    if reboot:
        pending = any(bool(v) for v in reboot.values())
        metrics["pending_reboot"] = 1 if pending else 0
        findings.append(Finding("OBSERVE" if pending else "PASS", "windows_os", "Pending reboot", f"Pending reboot flags: {reboot}", "Reboot during maintenance if pending."))

    out, err, code = run_ps("bcdedit /enum {current}", timeout=20)
    findings.append(Finding("INFO" if code == 0 else "INFO", "windows_os", "Boot configuration summary", "bcdedit current entry was readable." if code == 0 else f"bcdedit unavailable or limited: {err or out}", "Permission-limited result is not a confirmed fault."))

    page, err, code = ps_json("Get-CimInstance Win32_PageFileUsage | Select-Object Name,AllocatedBaseSize,CurrentUsage,PeakUsage")
    findings.append(Finding("INFO", "windows_os", "Pagefile usage", "Readable." if page else f"Unavailable: {err}", "Review only if memory pressure is high.", data={"pagefile": page} if page else {}))

    findings.append(Finding("INFO", "windows_os", "Locale/timezone", f"Locale={locale.getdefaultlocale()}, Timezone={time.tzname}, SystemRoot={os.environ.get('SystemRoot')}", "No action required."))
    return findings, metrics
