import psutil
from core.models import Finding
from core.utils import gb, fmt_bytes


def run(config, args, context=None):
    findings = []
    metrics = {}
    t = config["thresholds"]

    for p in psutil.disk_partitions(all=False):
        try:
            u = psutil.disk_usage(p.mountpoint)
        except Exception as exc:
            findings.append(Finding("INFO", "storage", f"Disk usage {p.mountpoint}", f"Unavailable: {exc}", "Permission-limited or transient volume; not a confirmed issue."))
            continue

        key = p.mountpoint.replace("\\", "").replace(":", "").replace("/", "_") or "root"
        metrics[f"disk_usage_percent.{key}"] = u.percent
        metrics[f"disk_free_gb.{key}"] = gb(u.free)

        tiny = u.total < 1024**3 and p.fstype.lower() in {"fat", "fat32", "exfat"}
        if tiny:
            findings.append(Finding("OBSERVE", "storage", f"Disk usage {p.mountpoint}", f"{u.percent:.1f}% used; {gb(u.free)} GB free of {gb(u.total)} GB. Filesystem: {p.fstype}. Tiny removable/FAT-style volume detected. This may be a USB, recovery, EFI, or utility volume.", "Verify what this small volume is before deleting or changing anything."))
        elif u.percent >= t["disk_critical"]:
            findings.append(Finding("CRITICAL", "storage", f"Disk usage {p.mountpoint}", f"{u.percent:.1f}% used; {gb(u.free)} GB free of {gb(u.total)} GB. Filesystem: {p.fstype}.", "Free disk space or move data."))
        elif u.percent >= t["disk_warning"]:
            findings.append(Finding("WARNING", "storage", f"Disk usage {p.mountpoint}", f"{u.percent:.1f}% used; {gb(u.free)} GB free of {gb(u.total)} GB. Filesystem: {p.fstype}.", "Review large files and application caches."))
        else:
            findings.append(Finding("PASS", "storage", f"Disk usage {p.mountpoint}", f"{u.percent:.1f}% used; {gb(u.free)} GB free of {gb(u.total)} GB. Filesystem: {p.fstype}. Disk free space is acceptable.", "No action required."))
    return findings, metrics
