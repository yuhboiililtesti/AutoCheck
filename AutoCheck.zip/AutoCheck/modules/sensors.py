from pathlib import Path
import psutil
from core.models import Finding
from core.utils import nvidia_smi_query, to_float


def run(config, args, context=None):
    findings = []
    metrics = {}
    t = config["thresholds"]
    found = False

    try:
        temps = psutil.sensors_temperatures(fahrenheit=False)
        if temps:
            found = True
            for chip, vals in temps.items():
                for s in vals:
                    name = s.label or chip
                    val = float(s.current)
                    metrics[f"sensor_temp_c.{chip}.{name}"] = val
                    sev = "PASS"
                    if "cpu" in (chip + name).lower() and val >= t["cpu_temp_critical_c"]:
                        sev = "CRITICAL"
                    elif "cpu" in (chip + name).lower() and val >= t["cpu_temp_warning_c"]:
                        sev = "WARNING"
                    findings.append(Finding(sev, "sensors", f"Temperature sensor: {name}", f"{val:.1f} C", "Review cooling only if temperatures are high."))
    except Exception:
        pass

    rows, err = nvidia_smi_query(["temperature.gpu", "utilization.gpu", "memory.used", "memory.total", "power.draw"])
    if rows:
        found = True
        g = rows[0]
        temp = to_float(g.get("temperature.gpu"), 0)
        metrics["gpu_temp_c"] = temp
        sev = "CRITICAL" if temp >= t["gpu_temp_critical_c"] else "WARNING" if temp >= t["gpu_temp_warning_c"] else "PASS"
        findings.append(Finding(sev, "sensors", "NVIDIA GPU temperature", f"{temp:.1f} C.", "Review GPU cooling if high.", data=g))

    dll = Path("external/LibreHardwareMonitor/LibreHardwareMonitorLib.dll")
    if dll.exists():
        try:
            import clr
            clr.AddReference(str(dll.resolve()))
            findings.append(Finding("INFO", "sensors", "LibreHardwareMonitor", "DLL found and load attempted.", "Use vendor tools to validate sensor values."))
        except Exception as exc:
            findings.append(Finding("INFO", "sensors", "LibreHardwareMonitor", f"DLL exists but could not load: {exc}", "Optional integration only."))
    else:
        findings.append(Finding("INFO", "sensors", "LibreHardwareMonitor", "DLL not present.", "Optional only."))

    if not found:
        findings.append(Finding("OBSERVE", "sensors", "Temperature sensors", "No temperature sensors were available through psutil or nvidia-smi.", "Use vendor tools if you need verified CPU/GPU temperatures."))
    return findings, metrics
