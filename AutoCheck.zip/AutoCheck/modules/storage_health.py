from core.models import Finding
from core.utils import is_windows, ps_json


def _safe_ps_json(script, timeout=20):
    try:
        return ps_json(script, timeout=timeout)
    except Exception as exc:
        return None, str(exc), 1


def run(config, args, context=None):
    findings = []
    metrics = {}

    if not is_windows():
        findings.append(Finding(
            "OBSERVE",
            "storage_health",
            "Storage health checks require Windows",
            "PhysicalDisk/CIM health checks are Windows-specific.",
            "Run on Windows."
        ))
        return findings, metrics

    disks, err, code = _safe_ps_json(
        "Get-PhysicalDisk | Select-Object FriendlyName,HealthStatus,OperationalStatus,MediaType,Size",
        timeout=20
    )

    if disks:
        items = disks if isinstance(disks, list) else [disks]
        metrics["physical_disk_count"] = len(items)
        for d in items:
            health = str(d.get("HealthStatus", "Unknown"))
            op = str(d.get("OperationalStatus", "Unknown"))
            text = (health + " " + op).lower()

            sev = "PASS"
            if any(x in text for x in ["unhealthy", "failed", "lost", "degraded"]):
                sev = "CRITICAL"
            elif health.lower() not in {"healthy", "ok"} and "ok" not in op.lower():
                sev = "OBSERVE"

            findings.append(Finding(
                sev,
                "storage_health",
                "Physical disk health",
                f"{d.get('FriendlyName')}: Health={health}, Operational={op}, Media={d.get('MediaType')}.",
                "Back up important data and review vendor tools if degraded.",
                data=d
            ))
    else:
        findings.append(Finding(
            "INFO",
            "storage_health",
            "Physical disk health unavailable",
            err or "Get-PhysicalDisk returned no data or timed out.",
            "This can be permission, driver, or Storage Spaces dependent. Not a confirmed disk fault."
        ))

    volumes, verr, vcode = _safe_ps_json(
        "Get-Volume | Select-Object DriveLetter,FileSystemLabel,FileSystem,HealthStatus,OperationalStatus,SizeRemaining,Size",
        timeout=20
    )

    if volumes:
        items = volumes if isinstance(volumes, list) else [volumes]
        metrics["volume_health_count"] = len(items)
        findings.append(Finding(
            "INFO",
            "storage_health",
            "Volume health inventory",
            f"{len(items)} volume health row(s) returned by Get-Volume.",
            "Review only if HealthStatus or OperationalStatus is not healthy.",
            data={"volumes": items[:50]}
        ))
    else:
        findings.append(Finding(
            "INFO",
            "storage_health",
            "Volume health unavailable",
            verr or "Get-Volume returned no data or timed out.",
            "Permission/platform limited result."
        ))

    return findings, metrics
