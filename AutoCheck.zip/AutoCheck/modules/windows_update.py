from core.models import Finding
from core.utils import is_windows, ps_json


def _service_status_name(value):
    names = {
        1: "Stopped",
        2: "StartPending",
        3: "StopPending",
        4: "Running",
        5: "ContinuePending",
        6: "PausePending",
        7: "Paused",
    }
    try:
        return names.get(int(value), str(value))
    except Exception:
        return str(value)


def _start_type_name(value):
    names = {
        0: "Boot",
        1: "System",
        2: "Automatic",
        3: "Manual",
        4: "Disabled",
    }
    try:
        return names.get(int(value), str(value))
    except Exception:
        return str(value)


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "windows_update", "Windows Update unavailable", "This module requires Windows.", "Run on Windows.")], {}

    findings = []
    metrics = {}

    # Use CIM because PowerShell's Get-Service object can serialize enums as raw numbers.
    svc, err, code = ps_json("Get-CimInstance Win32_Service -Filter \"Name='wuauserv'\" | Select-Object Name,State,StartMode,Status")
    if svc:
        state = svc.get("State")
        start = svc.get("StartMode")
        metrics["windows_update_service_visible"] = 1
        findings.append(Finding(
            "PASS" if str(state).lower() == "running" else "OBSERVE",
            "windows_update",
            "Windows Update service",
            f"State={state}; StartMode={start}; Status={svc.get('Status')}",
            "Stopped service can be normal if idle; review only if updates fail.",
            data=svc,
        ))
    else:
        # Fallback to Get-Service and map numeric enum values.
        svc2, err2, code2 = ps_json("Get-Service wuauserv | Select-Object Name,Status,StartType")
        if svc2:
            status = _service_status_name(svc2.get("Status"))
            start = _start_type_name(svc2.get("StartType"))
            findings.append(Finding(
                "PASS" if status == "Running" else "OBSERVE",
                "windows_update",
                "Windows Update service",
                f"Status={status}; StartType={start}",
                "Stopped service can be normal if idle; review only if updates fail.",
                data=svc2,
            ))
        else:
            findings.append(Finding("INFO", "windows_update", "Windows Update service", f"Unavailable: {err or err2}", "Permission-limited result."))

    hotfix, err, code = ps_json("Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -First 1 HotFixID,Description,InstalledOn,InstalledBy")
    findings.append(Finding("INFO", "windows_update", "Most recent hotfix", f"{hotfix}" if hotfix else f"Unavailable: {err}", "No online update check is performed.", data={"hotfix": hotfix} if hotfix else {}))

    hist, herr, hcode = ps_json("(New-Object -ComObject Microsoft.Update.Session).QueryHistory('',0,20) | Select-Object Title,Date,ResultCode", timeout=60)
    if hist:
        items = hist if isinstance(hist, list) else [hist]
        metrics["windows_update_history_visible_count"] = len(items)
        findings.append(Finding("INFO", "windows_update", "Recent Windows Update history", f"{len(items)} recent update history row(s) visible.", "Review failed result codes only if updates are failing.", data={"history": items[:20]}))
    else:
        findings.append(Finding("INFO", "windows_update", "Recent Windows Update history", f"Unavailable: {herr}", "This can be COM/permission limited and is not a confirmed fault."))

    return findings, metrics
