from core.models import Finding
from core.utils import is_windows, ps_json


def run(config, args, context=None):
    if not is_windows():
        return [Finding("OBSERVE", "scheduled_tasks", "Scheduled tasks unavailable", "This module requires Windows.", "Run on Windows.")], {}
    data, err, code = ps_json("Get-ScheduledTask | Select-Object TaskName,TaskPath,State")
    if not data:
        return [Finding("INFO", "scheduled_tasks", "Scheduled tasks count", f"Unavailable: {err}", "Permission-limited result; not a confirmed fault.")], {}
    items = data if isinstance(data, list) else [data]
    disabled = sum(1 for t in items if str(t.get("State")).lower() == "disabled")
    return [Finding("INFO", "scheduled_tasks", "Scheduled tasks count", f"{len(items)} scheduled task(s) found; {disabled} disabled.", "Review Task Scheduler manually if unknown tasks are suspected.")], {"scheduled_task_count": len(items), "scheduled_task_disabled_count": disabled}
