from core.models import Finding
from core.utils import is_windows, ps_json


def run(config, args, context=None):
    findings = []
    metrics = {}
    if not is_windows():
        return [Finding("OBSERVE", "security", "Security checks unavailable", "This module requires Windows.", "Run on Windows.")], {}

    data, err, code = ps_json("Get-MpComputerStatus | Select-Object AntivirusEnabled,AntispywareEnabled,RealTimeProtectionEnabled,AMServiceEnabled")
    if data:
        checks = [
            ("Defender antivirus enabled", "AntivirusEnabled"),
            ("Defender antispyware enabled", "AntispywareEnabled"),
            ("Defender real-time protection", "RealTimeProtectionEnabled"),
        ]
        for title, key in checks:
            val = bool(data.get(key))
            metrics[key] = 1 if val else 0
            findings.append(Finding("PASS" if val else "WARNING", "security", title, f"PowerShell reported: {val}", "Enable or review Windows Security settings if this is false."))
    else:
        findings.append(Finding("INFO", "security", "Defender status", f"Unavailable: {err}", "May be unavailable with third-party AV or permissions."))

    fw, ferr, code = ps_json("Get-NetFirewallProfile | Select-Object Name,Enabled")
    if fw:
        items = fw if isinstance(fw, list) else [fw]
        for item in items:
            enabled = bool(item.get("Enabled"))
            findings.append(Finding("PASS" if enabled else "WARNING", "security", f"Firewall profile {item.get('Name')}", f"Enabled={enabled}", "Enable firewall unless intentionally managed by policy."))
    return findings, metrics
