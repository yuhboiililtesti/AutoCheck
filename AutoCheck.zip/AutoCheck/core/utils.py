import ctypes
import datetime as dt
import json
import os
import platform
import shutil
import socket
import subprocess
import tempfile
from pathlib import Path


def now():
    return dt.datetime.now()


def now_str():
    return now().strftime("%Y-%m-%d %H:%M:%S")


def iso_now():
    return now().isoformat(timespec="seconds")


def report_date_mdy():
    d = now()
    return f"{d.month}-{d.day}-{str(d.year)[-2:]}"


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def safe_json(obj):
    return json.dumps(obj, indent=2, default=str, ensure_ascii=False)


def read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def write_json(path, obj):
    ensure_dir(str(Path(path).parent))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=str, ensure_ascii=False)


def safe_report_filename(mode, report_dir):
    ensure_dir(report_dir)
    base = f"autocheck_{mode}_{report_date_mdy()}.txt"
    candidate = Path(report_dir) / base
    if not candidate.exists():
        return str(candidate.resolve())
    i = 2
    while True:
        candidate = Path(report_dir) / base.replace(".txt", f"_{i}.txt")
        if not candidate.exists():
            return str(candidate.resolve())
        i += 1


def is_windows():
    return platform.system().lower() == "windows"


def is_admin():
    if not is_windows():
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def which(name):
    return shutil.which(name)


def powershell_path():
    return shutil.which("powershell") or shutil.which("pwsh")


def run_cmd(cmd, timeout=45, shell=True):
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            shell=shell,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
        )
        return proc.stdout.strip(), proc.stderr.strip(), int(proc.returncode)
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124
    except Exception as exc:
        return "", str(exc), 1


def run_ps(script, timeout=60):
    exe = powershell_path()
    if not exe:
        return "", "PowerShell not found in PATH.", 127
    return run_cmd([exe, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], timeout=timeout, shell=False)


def parse_powershell_json(text):
    if not text:
        return None
    text = text.strip()
    if text.startswith("\ufeff"):
        text = text[1:]
    try:
        return json.loads(text)
    except Exception:
        return None


def ps_json(script, timeout=60):
    out, err, code = run_ps(f"{script} | ConvertTo-Json -Depth 8", timeout=timeout)
    if code != 0:
        return None, err or out, code
    parsed = parse_powershell_json(out)
    if parsed is None and out:
        return None, out[:1000], code
    return parsed, "", 0


def nvidia_smi_query(fields, timeout=10):
    exe = which("nvidia-smi")
    if not exe:
        return None, "nvidia-smi not found in PATH."
    query = ",".join(fields)
    out, err, code = run_cmd([exe, f"--query-gpu={query}", "--format=csv,noheader,nounits"], timeout=timeout, shell=False)
    if code != 0:
        return None, err or out or "nvidia-smi failed."
    rows = []
    for line in out.splitlines():
        parts = [p.strip() for p in line.split(",")]
        rows.append({field: parts[i] if i < len(parts) else "" for i, field in enumerate(fields)})
    return rows, ""


def to_float(value, default=None):
    try:
        s = str(value).replace(",", "").replace("%", "").replace("[N/A]", "").strip()
        if not s or s.upper() == "N/A":
            return default
        return float(s)
    except Exception:
        return default


def to_int(value, default=None):
    f = to_float(value, None)
    return default if f is None else int(f)


def gb(bytes_value):
    return round(float(bytes_value) / (1024 ** 3), 2)


def mb(bytes_value):
    return round(float(bytes_value) / (1024 ** 2), 2)


def fmt_bytes(bytes_value):
    try:
        n = float(bytes_value)
    except Exception:
        return "unknown"
    for unit in ["B", "KB", "MB", "GB", "TB", "PB"]:
        if abs(n) < 1024:
            return f"{n:.2f} {unit}"
        n /= 1024
    return f"{n:.2f} EB"


def tcp_connect(host, port, timeout=3):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def temp_file_path(prefix="autocheck_", suffix=".tmp"):
    fd, path = tempfile.mkstemp(prefix=prefix, suffix=suffix)
    os.close(fd)
    return path


def flatten_numeric_metrics(metrics):
    flat = {}

    def walk(prefix, value):
        if isinstance(value, dict):
            for k, v in value.items():
                walk(f"{prefix}.{k}" if prefix else str(k), v)
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            flat[prefix] = float(value)

    walk("", metrics)
    return flat


def safe_log_filename(mode, logs_dir, suffix="full", ext=".txt"):
    import os
    from datetime import datetime

    os.makedirs(logs_dir, exist_ok=True)
    d = datetime.now()
    # M-D-YY format per project requirement.
    date_part = f"{d.month}-{d.day}-{str(d.year)[-2:]}"
    base = f"autocheck_{mode}_{suffix}_{date_part}"
    path = os.path.join(logs_dir, base + ext)
    i = 2
    while os.path.exists(path):
        path = os.path.join(logs_dir, f"{base}_{i}{ext}")
        i += 1
    return path
