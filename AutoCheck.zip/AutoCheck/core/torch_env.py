import json
import os
import sys
import tempfile
from core.utils import run_cmd, which

GPU_STRESS_SCRIPT = '\nimport gc\nimport json\nimport random\nimport subprocess\nimport sys\nimport time\n\nduration = int(sys.argv[1])\ntarget_vram_percent = float(sys.argv[2])\nstop_temp = float(sys.argv[3])\nfrag_duration = int(sys.argv[4])\nfrag_min_mb = int(sys.argv[5])\nfrag_max_mb = int(sys.argv[6])\nutil_target = float(sys.argv[7])\n\ndef smi():\n    try:\n        out = subprocess.check_output([\n            "nvidia-smi",\n            "--query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total,power.draw,clocks.gr,clocks.mem",\n            "--format=csv,noheader,nounits"\n        ], text=True, timeout=5)\n        p = [x.strip() for x in out.splitlines()[0].split(",")]\n        def f(x):\n            try:\n                return float(x)\n            except Exception:\n                return 0.0\n        return {\n            "util": f(p[0]), "temp": f(p[1]), "used": f(p[2]), "total": f(p[3]),\n            "power": f(p[4]), "graphics_clock": f(p[5]), "memory_clock": f(p[6])\n        }\n    except Exception:\n        return None\n\ntry:\n    import torch\n    if not torch.cuda.is_available():\n        raise RuntimeError("torch.cuda.is_available() returned false")\n\n    torch.backends.cuda.matmul.allow_tf32 = True\n    torch.backends.cudnn.allow_tf32 = True\n\n    device = torch.device("cuda:0")\n    props = torch.cuda.get_device_properties(device)\n    total_mb = props.total_memory / (1024 * 1024)\n\n    # Reserve headroom to avoid OOM on display GPU / Windows WDDM.\n    target_mb = min(total_mb * target_vram_percent / 100.0, total_mb * 0.72)\n\n    # Fragmentation phase with bounded pressure.\n    frag_blocks = []\n    frag_allocated_mb = 0\n    frag_cap_mb = min(total_mb * 0.25, 4096)\n    frag_start = time.time()\n    while time.time() - frag_start < frag_duration and frag_allocated_mb < frag_cap_mb:\n        size_mb = random.randint(frag_min_mb, min(frag_max_mb, 256))\n        elems = int((size_mb * 1024 * 1024) / 2)\n        try:\n            frag_blocks.append(torch.empty((elems,), device=device, dtype=torch.float16))\n            frag_allocated_mb += size_mb\n        except Exception:\n            if frag_blocks:\n                idx = random.randrange(len(frag_blocks))\n                del frag_blocks[idx]\n                torch.cuda.empty_cache()\n                gc.collect()\n        if frag_blocks and random.random() < 0.45:\n            idx = random.randrange(len(frag_blocks))\n            del frag_blocks[idx]\n            torch.cuda.empty_cache()\n\n    # Compute matrix allocation with aggressive backoff.\n    candidates = [8192, 7168, 6144, 5120, 4096, 3072, 2048]\n    a = b = None\n    last_err = None\n    for n in candidates:\n        try:\n            torch.cuda.empty_cache()\n            a = torch.randn((n, n), device=device, dtype=torch.float16)\n            b = torch.randn((n, n), device=device, dtype=torch.float16)\n            break\n        except Exception as e:\n            last_err = e\n            a = b = None\n            torch.cuda.empty_cache()\n            gc.collect()\n\n    if a is None or b is None:\n        raise RuntimeError("Unable to allocate CUDA matrices after backoff: " + str(last_err))\n\n    # VRAM fill with headroom and backoff.\n    keep = []\n    block_mb = 128\n    block_elems = int((block_mb * 1024 * 1024) / 2)\n    allocated_mb = 0\n    while allocated_mb + block_mb < target_mb:\n        g = smi()\n        if g and g["used"] > target_mb:\n            break\n        try:\n            keep.append(torch.empty((block_elems,), device=device, dtype=torch.float16))\n            allocated_mb += block_mb\n        except Exception:\n            break\n\n    peak_util = peak_temp = peak_vram = peak_power = 0\n    peak_graphics_clock = peak_memory_clock = 0\n    samples = iterations = 0\n    inner_loops = 6\n    start = time.time()\n    end = start + duration\n\n    # Warmup.\n    for _ in range(2):\n        c = torch.matmul(a, b)\n        torch.cuda.synchronize()\n        del c\n\n    while time.time() < end:\n        try:\n            for _ in range(inner_loops):\n                c = torch.matmul(a, b)\n                d = torch.relu(c)\n                e = torch.matmul(d, b)\n                torch.cuda.synchronize()\n                del c, d, e\n                iterations += 1\n        except Exception as e:\n            # Back off pressure if CUDA OOM occurs mid-run.\n            if keep:\n                del keep[max(0, len(keep)//2):]\n            if frag_blocks:\n                del frag_blocks[max(0, len(frag_blocks)//2):]\n            torch.cuda.empty_cache()\n            gc.collect()\n            inner_loops = max(2, inner_loops - 2)\n            continue\n\n        g = smi()\n        if g:\n            samples += 1\n            peak_util = max(peak_util, g["util"])\n            peak_temp = max(peak_temp, g["temp"])\n            peak_vram = max(peak_vram, g["used"])\n            peak_power = max(peak_power, g["power"])\n            peak_graphics_clock = max(peak_graphics_clock, g["graphics_clock"])\n            peak_memory_clock = max(peak_memory_clock, g["memory_clock"])\n\n            if g["util"] < util_target and inner_loops < 24:\n                inner_loops += 2\n            elif g["util"] > 98 and inner_loops > 4:\n                inner_loops -= 1\n\n            print(json.dumps({"progress": True, **g, "inner_loops": inner_loops}), flush=True)\n            if g["temp"] >= stop_temp:\n                break\n\n    elapsed = max(0.001, time.time() - start)\n    approx_tflops = (2 * (n ** 3) * max(iterations, 1)) / elapsed / 1e12\n\n    print(json.dumps({\n        "ok": True,\n        "python": sys.executable,\n        "torch_version": torch.__version__,\n        "cuda_version": getattr(torch.version, "cuda", None),\n        "device": torch.cuda.get_device_name(0),\n        "matrix_n": n,\n        "target_vram_mb": target_mb,\n        "fragmentation_blocks_remaining": len(frag_blocks),\n        "fragmentation_alloc_attempt_mb": frag_allocated_mb,\n        "allocated_vram_blocks_mb": allocated_mb,\n        "peak_util": peak_util,\n        "peak_temp": peak_temp,\n        "peak_vram": peak_vram,\n        "peak_power": peak_power,\n        "peak_graphics_clock": peak_graphics_clock,\n        "peak_memory_clock": peak_memory_clock,\n        "samples": samples,\n        "iterations": iterations,\n        "elapsed": elapsed,\n        "approx_tflops": approx_tflops,\n        "oom_backoff_enabled": True\n    }), flush=True)\n\nexcept Exception as e:\n    print(json.dumps({"ok": False, "python": sys.executable, "error": str(e)}), flush=True)\n'


def current_python_torch_status(timeout=20):
    code = """
import json
import sys
try:
    import torch
    print(json.dumps({
        "ok": True,
        "python": sys.executable,
        "version": sys.version,
        "torch_version": getattr(torch, "__version__", None),
        "cuda_available": bool(torch.cuda.is_available()),
        "cuda_version": getattr(torch.version, "cuda", None),
        "device_count": torch.cuda.device_count(),
        "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    }))
except Exception as e:
    print(json.dumps({
        "ok": False,
        "python": sys.executable,
        "version": sys.version,
        "error": str(e)
    }))
"""
    out, err, rc = run_cmd([sys.executable, "-c", code], timeout=timeout, shell=False)
    try:
        return json.loads(out), err
    except Exception:
        return {"ok": False, "python": sys.executable, "error": err or out or "Unable to query torch."}, err


def candidate_python_commands():
    cmds = []
    if sys.executable:
        cmds.append([sys.executable])
    for ver in ["3.12", "3.11", "3.10", "3.13", "3.14"]:
        cmds.append(["py", f"-{ver}"])
    for name in ["python", "python3"]:
        if which(name):
            cmds.append([name])
    seen = set()
    result = []
    for c in cmds:
        key = " ".join(c).lower()
        if key not in seen:
            seen.add(key)
            result.append(c)
    return result


def query_python_command(cmd, timeout=25):
    code = """
import json
import sys
payload={"python": sys.executable, "version": sys.version, "ok": False}
try:
    import torch
    payload.update({
        "ok": True,
        "torch_version": getattr(torch, "__version__", None),
        "cuda_available": bool(torch.cuda.is_available()),
        "cuda_version": getattr(torch.version, "cuda", None),
        "device_count": torch.cuda.device_count(),
        "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    })
except Exception as e:
    payload.update({"error": str(e)})
print(json.dumps(payload))
"""
    out, err, rc = run_cmd(cmd + ["-c", code], timeout=timeout, shell=False)
    try:
        data = json.loads(out)
        data["command"] = cmd
        data["returncode"] = rc
        return data
    except Exception:
        return {"command": cmd, "ok": False, "returncode": rc, "error": err or out or "query failed"}


def discover_cuda_python():
    results = []
    for cmd in candidate_python_commands():
        data = query_python_command(cmd)
        results.append(data)
        if data.get("ok") and data.get("cuda_available"):
            return data, results
    return None, results


def run_external_cuda_stress(
    python_cmd,
    duration=75,
    target_vram_percent=80,
    stop_temp=85,
    timeout=360,
    frag_duration=45,
    frag_min_mb=32,
    frag_max_mb=512,
    util_target=90,
):
    script_path = None
    try:
        fd, script_path = tempfile.mkstemp(prefix="autocheck_cuda_stress_", suffix=".py")
        os.close(fd)
        with open(script_path, "w", encoding="utf-8") as fh:
            fh.write(GPU_STRESS_SCRIPT)

        cmd = python_cmd + [
            script_path,
            str(int(duration)),
            str(float(target_vram_percent)),
            str(float(stop_temp)),
            str(int(frag_duration)),
            str(int(frag_min_mb)),
            str(int(frag_max_mb)),
            str(float(util_target)),
        ]
        out, err, rc = run_cmd(cmd, timeout=timeout, shell=False)

        final = None
        progress = []
        for line in out.splitlines():
            try:
                obj = json.loads(line)
                if obj.get("progress"):
                    progress.append(obj)
                else:
                    final = obj
            except Exception:
                continue

        if final is None:
            final = {"ok": False, "error": err or out or "External CUDA stress produced no final JSON.", "returncode": rc}

        final["command"] = python_cmd
        final["stderr"] = err
        final["returncode"] = rc
        final["progress_samples"] = progress[-10:]
        return final
    finally:
        if script_path:
            try:
                os.remove(script_path)
            except Exception:
                pass
