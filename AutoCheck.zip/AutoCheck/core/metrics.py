class MetricsStore:
    def __init__(self):
        self.data = {}

    def merge(self, values):
        if values:
            self.data.update(values)

    def get(self):
        return dict(self.data)
