import importlib
import time
from core.anomaly import compare_to_baseline, compare_to_history
from core.baseline import BaselineManager
from core.history import HistoryManager
from core.metrics import MetricsStore
from core.models import Finding, ScanResult
from core.postprocess import normalize, prioritize
from core.scoring import component_scores


DISPLAY_NAMES = {
    "autocheck_selftest": "environment",
    "windows_os": "windows os",
    "hardware_deep": "deep hardware",
    "storage": "disks",
    "storage_health": "disk health",
    "network_deep": "deep network",
    "security_deep": "deep security",
    "windows_update": "windows update",
    "installed_updates": "installed updates",
    "windows_events": "windows events",
    "event_intelligence": "event intelligence",
    "scheduled_tasks": "scheduled tasks",
}


def _dedupe_key(f):
    # Key by semantic identity, not round-specific details.
    return (str(f.category).lower(), str(f.title).lower(), str(f.suggestion).lower())


class Runner:
    def __init__(self, config, args):
        self.config = config
        self.args = args
        self.baseline = BaselineManager(config)
        self.history = HistoryManager(config)

    def _label(self, check):
        return DISPLAY_NAMES.get(check, check.replace("_", " "))

    def _execute(self, check, mode, round_num, total_rounds):
        module = importlib.import_module(f"modules.{check}")
        context = {
            "mode": mode,
            "round": round_num,
            "total_rounds": total_rounds,
            "is_final_round": round_num == total_rounds,
            "intensity_percent": int(self.config["scan_profiles"][mode].get("intensity_percent", 100)),
        }
        return module.run(self.config, self.args, context)

    def _round_variation(self, round_metrics):
        findings = []
        if len(round_metrics) < 2:
            return findings

        a, b = round_metrics[0], round_metrics[-1]
        changed = []
        for k, va in a.items():
            vb = b.get(k)
            if isinstance(va, (int, float)) and isinstance(vb, (int, float)):
                base = abs(va) if va else 1
                pct = abs(vb - va) / base * 100
                if pct >= 25:
                    changed.append({"metric": k, "round_1": va, "round_2": vb, "percent": round(pct, 1)})

        if changed:
            findings.append(Finding(
                "OBSERVE",
                "verification",
                "Round-to-round variation detected",
                f"{len(changed)} metric group(s) changed between repeated hard-scan rounds.",
                "Usually normal for CPU, memory, process count, services, and network timing. Review only if the same symptom is causing real problems.",
                data={"changed_metrics": changed[:50]},
            ))
        return findings

    def _merge_repeated_findings(self, findings):
        """
        Hard mode repeats scans. This merges duplicate findings so the report does not list
        the same legacy disk tool/E:\\/svchost/etc. observation twice. If details differ, it combines them
        into a round-aware detail line.
        """
        severity_rank = {"PASS": 0, "INFO": 1, "OBSERVE": 2, "WARNING": 3, "CRITICAL": 4}
        merged = {}

        for f in findings:
            key = _dedupe_key(f)
            if key not in merged:
                merged[key] = f
                continue

            cur = merged[key]
            if severity_rank.get(f.severity, 2) > severity_rank.get(cur.severity, 2):
                cur.severity = f.severity

            if f.detail != cur.detail:
                if "round 1:" not in cur.detail and "round 2:" not in cur.detail:
                    cur.detail = f"round detail: {cur.detail}"
                if f.detail not in cur.detail:
                    cur.detail += f" | repeat detail: {f.detail}"

            # Preserve data without overwriting meaningful original data.
            if f.data:
                cur.data.setdefault("repeated_data", [])
                cur.data["repeated_data"].append(f.data)

        return list(merged.values())


    def _context_intelligence(self, metrics, findings):
        """Add lightweight cross-module intelligence without changing scanner modules."""
        extra = []
        app_events = int(metrics.get("application_critical_error_events_24h") or 0)
        sys_events = int(metrics.get("system_critical_error_events_24h") or 0)
        pnp_count = int(metrics.get("pnp_problem_device_count") or 0)
        tpm_resolved = metrics.get("tpm_query_resolved")
        is_admin = int(metrics.get("is_admin") or 0)

        if pnp_count > 0:
            has_detail = any(str(f.category).lower() == "hardware_deep" and "pnp" in str(f.title).lower() for f in findings)
            if not has_detail:
                extra.append(Finding(
                    "OBSERVE", "hardware_deep", "Problem device context missing",
                    f"pnp_problem_device_count={pnp_count}, but no expanded device finding was produced.",
                    "Rerun as administrator or review Device Manager for the exact device and ConfigManagerErrorCode.",
                    data={"pnp_problem_device_count": pnp_count},
                ))

        if app_events > 0:
            extra.append(Finding(
                "OBSERVE", "windows_events", "Application error context required",
                f"{app_events} Application critical/error event(s) were counted in the last 24h.",
                "Review the full Windows Events section for grouped providers and message previews; investigate only if this matches visible crashes or hangs.",
                data={"application_critical_error_events_24h": app_events},
            ))

        if tpm_resolved == 0:
            extra.append(Finding(
                "OBSERVE", "security_deep", "TPM unresolved after fallback",
                "TPM state could not be resolved by available TPM probes.",
                "Rerun from an elevated terminal and verify firmware TPM/AMD fTPM if TPM-backed Windows security features are expected.",
                data={"tpm_query_resolved": tpm_resolved, "is_admin": is_admin},
            ))

        if app_events > 0 and pnp_count > 0:
            extra.append(Finding(
                "OBSERVE", "correlation", "Application errors plus device issue",
                f"Application errors ({app_events}) and PnP problem devices ({pnp_count}) were both detected in the same scan.",
                "This is not proof of causation. Prioritize the problem device details and app-event providers if crashes or freezes are occurring.",
                data={"application_critical_error_events_24h": app_events, "pnp_problem_device_count": pnp_count},
            ))

        if sys_events > 0 and (metrics.get("event_storage_signals") or metrics.get("event_gpu_signals") or metrics.get("event_whea_signals")):
            extra.append(Finding(
                "OBSERVE", "correlation", "System event pattern correlation",
                "System error events overlap with event-intelligence hardware/storage/GPU signal counters.",
                "Review Event Intelligence first because it already filters common event noise.",
                data={
                    "system_critical_error_events_24h": sys_events,
                    "event_storage_signals": metrics.get("event_storage_signals"),
                    "event_gpu_signals": metrics.get("event_gpu_signals"),
                    "event_whea_signals": metrics.get("event_whea_signals"),
                },
            ))

        return extra

    def run(self, mode):
        profile = self.config["scan_profiles"][mode]
        repeat = int(profile.get("repeat", 1))
        intensity = int(profile.get("intensity_percent", 100))
        checks = list(profile.get("checks", []))

        findings = []
        round_metrics = []
        module_status = {}

        print(f"Scan intensity target: {intensity}%")

        for round_num in range(1, repeat + 1):
            print(f"\nRunning {mode.upper()} scan round {round_num}/{repeat}...")
            store = MetricsStore()

            for check in checks:
                if check == "stress" and (mode != "hard" or round_num != repeat):
                    print("  - Stress test reserved for final hard-scan round")
                    module_status[f"{check}:round{round_num}"] = "reserved for final hard-scan round"
                    continue

                if check == "stress" and getattr(self.args, "no_stress", False):
                    print("  - Skipping stress (--no-stress)")
                    module_status[f"{check}:round{round_num}"] = "skipped by --no-stress"
                    findings.append(Finding("INFO", "stress", "Stress test skipped", "Stress test was skipped by --no-stress.", "Run hard scan without --no-stress to test CPU/RAM/Disk/GPU."))
                    continue

                print(f"  - Checking {self._label(check)}", flush=True)
                started = time.perf_counter()

                try:
                    f, m = self._execute(check, mode, round_num, repeat)
                    elapsed = time.perf_counter() - started
                    print(f"    done in {elapsed:.1f}s", flush=True)
                    findings.extend(f or [])
                    store.merge(m or {})
                    module_status[f"{check}:round{round_num}"] = f"ok ({elapsed:.1f}s)"
                    store.merge({f"module_time_seconds.{check}.round{round_num}": round(elapsed, 2)})
                except Exception as exc:
                    elapsed = time.perf_counter() - started
                    print(f"    module failed safely in {elapsed:.1f}s: {check}", flush=True)
                    module_status[f"{check}:round{round_num}"] = f"failed safely ({elapsed:.1f}s): {exc}"
                    findings.append(Finding(
                        "OBSERVE",
                        "runner",
                        f"Module failed safely: {check}",
                        str(exc),
                        "Review permissions, Windows feature availability, and module output. AutoCheck continued without changing the system.",
                        source=check,
                    ))

            round_metrics.append(store.get())

        final_metrics = round_metrics[-1] if round_metrics else {}
        findings.extend(self._round_variation(round_metrics))

        saved_baseline = None
        baseline_data = self.baseline.load(mode)
        if getattr(self.args, "set_baseline", False):
            saved_baseline = self.baseline.save(mode, final_metrics)
            baseline_data = final_metrics
            findings.append(Finding("INFO", "baseline", "Baseline saved", f"Baseline saved to {saved_baseline}.", "Future scans can compare against this baseline."))
        elif not baseline_data and not getattr(self.args, "no_save", False):
            saved_baseline = self.baseline.save(mode, final_metrics)
            baseline_data = final_metrics
            findings.append(Finding("INFO", "baseline", "Baseline auto-created", f"No baseline existed, so AutoCheck created one at {saved_baseline}.", "Future scans will compare against this baseline automatically."))

        if not getattr(self.args, "no_baseline_compare", False):
            findings.extend(compare_to_baseline(final_metrics, baseline_data, self.config))
            findings.extend(compare_to_history(final_metrics, self.history.recent(mode), self.config))

        findings.extend(self._context_intelligence(final_metrics, findings))

        saved_history = None
        if not getattr(self.args, "no_save", False):
            saved_history = self.history.save(mode, final_metrics)

        findings = normalize(findings)
        findings = self._merge_repeated_findings(findings)
        findings = prioritize(findings)

        return ScanResult(
            mode=mode,
            findings=findings,
            metrics=final_metrics,
            round_metrics=round_metrics,
            module_status=module_status,
            component_scores=component_scores(findings),
            saved_history_path=saved_history,
            saved_baseline_path=saved_baseline,
        )
