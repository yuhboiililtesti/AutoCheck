
MULTIPROCESS_ALLOWLIST = {
    "svchost.exe", "msedgewebview2.exe", "opera.exe", "chrome.exe", "msedge.exe",
    "firefox.exe", "brave.exe", "steamwebhelper.exe", "discord.exe", "code.exe",
    "runtimebroker.exe", "conhost.exe", "openconsole.exe", "nvidia overlay.exe",
}

PERMISSION_TERMS = [
    "access denied", "permission", "administrator", "secureboot query failure",
    "bitlocker cim access denied", "unauthorized", "not available without elevation"
]

PRIORITY_CATEGORY = {
    "security_deep": 0,
    "hardware_deep": 1,
    "windows_events": 2,
    "event_intelligence": 3,
    "correlation": 4,
    "baseline": 5,
    "anomaly": 6,
    "storage_health": 7,
    "storage": 8,
    "drivers": 9,
    "processes": 10,
    "verification": 11,
}

PRIORITY_TITLE_TERMS = {
    "tpm": -5,
    "permission-limited": -4,
    "pnp": -4,
    "problem device": -4,
    "critical/error": -3,
    "application event": -3,
    "application crash": -3,
    "correlation": -3,
    "baseline": -2,
}

# Equivalent findings that should appear only once in the final report.
DEDUP_CANONICAL = [
    (("security_deep", "tpm"), "tpm_status"),
    (("windows_events", "application error context"), "app_event_context"),
    (("windows_events", "application event context"), "app_event_context"),
]

NON_FAULT_TITLE_TERMS = [
    "permission-limited scan context",
    "tpm unresolved after fallback",
    "tpm status",
    "round-to-round variation detected",
    "high instance count",
]


def _text(f):
    return f"{getattr(f, 'title', '')} {getattr(f, 'detail', '')} {getattr(f, 'suggestion', '')}".lower()


def _canonical_key(f):
    category = str(getattr(f, 'category', '')).lower()
    title = str(getattr(f, 'title', '')).lower()
    text = _text(f)
    for (cat, term), key in DEDUP_CANONICAL:
        if category == cat and term in text:
            return key
    # De-dupe repeated app-crash/context variants without collapsing unrelated providers.
    if category in {"windows_events", "event_intelligence"} and any(x in text for x in ["application critical/error", "application crash", "application error"]):
        return f"{category}:application_event_context"
    return (category, title.strip(), str(getattr(f, 'suggestion', '')).lower().strip())


def _deduplicate(findings):
    severity_rank = {"PASS": 0, "INFO": 1, "OBSERVE": 2, "WARNING": 3, "CRITICAL": 4}
    merged = {}
    order = []
    for f in findings:
        key = _canonical_key(f)
        if key not in merged:
            merged[key] = f
            order.append(key)
            continue
        cur = merged[key]
        if severity_rank.get(getattr(f, 'severity', 'OBSERVE'), 2) > severity_rank.get(getattr(cur, 'severity', 'OBSERVE'), 2):
            cur.severity = f.severity
        if getattr(f, 'detail', '') and f.detail != getattr(cur, 'detail', '') and f.detail not in cur.detail:
            # Preserve details in data, but avoid bloating the visible summary with duplicated text.
            cur.data.setdefault('deduplicated_details', [])
            cur.data['deduplicated_details'].append(f.detail)
        if getattr(f, 'data', None):
            cur.data.setdefault('deduplicated_data', [])
            cur.data['deduplicated_data'].append(f.data)
    return [merged[k] for k in order]


def normalize(findings):
    """Normalize severity, remove duplicated intelligence, and keep non-fault context from hurting health scoring."""
    for f in findings:
        text = _text(f)
        category = str(getattr(f, 'category', '')).lower()

        if any(x in text for x in PERMISSION_TERMS) and f.severity in {"WARNING", "CRITICAL"}:
            f.severity = "OBSERVE"
            if "Permission-limited results" not in f.suggestion:
                f.suggestion += " Permission-limited results are not counted as confirmed system failures."

        if "configmanagererrorcode 22" in text or "disabled device" in text:
            # Code 22 is usually disabled-by-user/device-manager state, not a fault.
            f.severity = "INFO" if category != "hardware_deep" else "OBSERVE"

        if "tpm" in text and any(x in text for x in ["null", "not found", "unresolved", "could not be resolved"]):
            f.severity = "OBSERVE"
            f.data.setdefault("score_weight", 0)
            f.data.setdefault("confidence", "limited")

        if category in {"process", "processes"} and any(name in text for name in MULTIPROCESS_ALLOWLIST):
            if f.severity in {"WARNING", "CRITICAL"}:
                f.severity = "OBSERVE"
            f.data.setdefault("score_weight", 0)

        if any(x in text for x in ["permission-limited scan context", "round-to-round variation detected"]):
            f.data.setdefault("score_weight", 0)
            f.data.setdefault("confidence", "context")

        if any(x in text for x in ["distributedcom", "dcom", "gamebar", "gamingservices", "volsnap event 36"]):
            if f.severity == "CRITICAL":
                f.severity = "OBSERVE"

    return _deduplicate(findings)


def priority_key(f):
    severity_order = {"CRITICAL": 0, "WARNING": 1, "OBSERVE": 2, "INFO": 3, "PASS": 4}
    text = _text(f)
    boost = 0
    for term, value in PRIORITY_TITLE_TERMS.items():
        if term in text:
            boost += value
    return (
        severity_order.get(getattr(f, 'severity', 'OBSERVE'), 9),
        PRIORITY_CATEGORY.get(str(getattr(f, 'category', '')).lower(), 99) + boost,
        str(getattr(f, 'title', '')).lower(),
    )


def prioritize(findings):
    return sorted(findings, key=priority_key)
