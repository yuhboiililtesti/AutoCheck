from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional, List


@dataclass
class Finding:
    severity: str
    category: str
    title: str
    detail: str
    suggestion: str
    source: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    metric_name: Optional[str] = None
    metric_value: Optional[float] = None

    def __post_init__(self):
        valid = {"CRITICAL", "WARNING", "OBSERVE", "INFO", "PASS"}
        self.severity = str(self.severity).upper()
        if self.severity not in valid:
            self.severity = "OBSERVE"

    def to_dict(self):
        return asdict(self)


@dataclass
class ScanResult:
    mode: str
    findings: List[Finding]
    metrics: Dict[str, Any]
    round_metrics: List[Dict[str, Any]]
    module_status: Dict[str, str]
    component_scores: Dict[str, int]
    saved_history_path: Optional[str] = None
    saved_baseline_path: Optional[str] = None
