from statistics import mean
from core.models import Finding
from core.utils import flatten_numeric_metrics


LOWER_IS_WORSE = ["read_mbps", "write_mbps", "stress_avg_percent", "stress_peak_percent"]
HIGHER_IS_WORSE = ["percent", "latency", "ping", "loss", "temp", "usage", "count", "used", "power"]


def _is_bad_change(key, pct):
    k = key.lower()
    if any(x in k for x in LOWER_IS_WORSE):
        return pct < 0
    if any(x in k for x in HIGHER_IS_WORSE):
        return pct > 0
    return abs(pct) > 0


def _severity(abs_pct, thresholds):
    if abs_pct > thresholds["anomaly_critical_percent"]:
        return "CRITICAL"
    if abs_pct > thresholds["anomaly_warning_percent"]:
        return "WARNING"
    if abs_pct > thresholds["anomaly_info_percent"]:
        return "INFO"
    return None


def compare_to_baseline(current, baseline, config):
    findings = []
    if not baseline:
        return [Finding("INFO", "baseline", "No baseline found", "No baseline exists for this mode.", "Run with --set-baseline after confirming the system is healthy.")]

    cur = flatten_numeric_metrics(current)
    base = flatten_numeric_metrics(baseline)
    thresholds = config["thresholds"]

    for k, v in cur.items():
        if k not in base or base[k] == 0:
            continue
        pct = ((v - base[k]) / abs(base[k])) * 100
        if not _is_bad_change(k, pct):
            continue
        sev = _severity(abs(pct), thresholds)
        if sev:
            findings.append(Finding(sev, "baseline", f"Baseline drift: {k}", f"{k} changed from {base[k]:.2f} to {v:.2f} ({pct:+.1f}%).", "Review recent software/hardware changes and rerun to confirm.", metric_name=k, metric_value=v))
    return findings


def compare_to_history(current, rows, config):
    findings = []
    if len(rows) < 3:
        return findings

    cur = flatten_numeric_metrics(current)
    flats = [flatten_numeric_metrics(r) for r in rows]
    thresholds = config["thresholds"]

    for k, v in cur.items():
        vals = [r[k] for r in flats if k in r]
        if len(vals) < 3:
            continue
        avg = mean(vals)
        if avg == 0:
            continue
        pct = ((v - avg) / abs(avg)) * 100
        if not _is_bad_change(k, pct):
            continue
        sev = _severity(abs(pct), thresholds)
        if sev:
            findings.append(Finding(sev, "anomaly", f"Rolling anomaly: {k}", f"{k} is {pct:+.1f}% from recent average ({avg:.2f} -> {v:.2f}).", "Review if this persists across scans.", metric_name=k, metric_value=v))
    return findings
