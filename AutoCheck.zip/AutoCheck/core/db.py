import os
import sqlite3
from core.utils import safe_json, iso_now


def save_scan_to_db(config, result, report):
    path = os.path.abspath(config["app"].get("database", "autocheck.db"))
    conn = sqlite3.connect(path)
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mode TEXT NOT NULL,
                generated TEXT NOT NULL,
                score INTEGER,
                status TEXT,
                report_json TEXT NOT NULL
            )
        """)
        conn.execute(
            "INSERT INTO scans (mode, generated, score, status, report_json) VALUES (?, ?, ?, ?, ?)",
            (
                result.mode,
                iso_now(),
                report["json"].get("score"),
                report["json"].get("status"),
                safe_json(report["json"]),
            ),
        )
        conn.commit()
    finally:
        conn.close()
    return path
