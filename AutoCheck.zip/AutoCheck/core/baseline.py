import os
from core.utils import ensure_dir, iso_now, read_json, write_json


class BaselineManager:
    def __init__(self, config):
        self.dir = config["output"]["baselines_dir"]
        ensure_dir(self.dir)

    def path(self, mode):
        return os.path.abspath(os.path.join(self.dir, f"baseline_{mode}.json"))

    def save(self, mode, metrics):
        path = self.path(mode)
        write_json(path, {"mode": mode, "generated": iso_now(), "metrics": metrics})
        return path

    def load(self, mode):
        data = read_json(self.path(mode))
        if isinstance(data, dict):
            return data.get("metrics")
        return None
