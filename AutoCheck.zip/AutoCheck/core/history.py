import glob
import os
from core.utils import ensure_dir, iso_now, read_json, write_json


class HistoryManager:
    def __init__(self, config):
        self.dir = config["output"]["history_dir"]
        ensure_dir(self.dir)

    def save(self, mode, metrics):
        import datetime as dt
        path = os.path.join(self.dir, f"history_{mode}_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        write_json(path, {"mode": mode, "generated": iso_now(), "metrics": metrics})
        return os.path.abspath(path)

    def recent(self, mode, limit=10):
        rows = []
        files = sorted(glob.glob(os.path.join(self.dir, f"history_{mode}_*.json")), reverse=True)[:limit]
        for f in files:
            data = read_json(f)
            if isinstance(data, dict) and isinstance(data.get("metrics"), dict):
                rows.append(data["metrics"])
        return rows
