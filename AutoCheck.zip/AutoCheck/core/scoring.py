
COMPONENTS = [
    "System", "Windows OS", "Hardware", "Sensors", "Storage", "Processes",
    "Network", "Security", "Events", "Drivers/GPU", "Stress", "Baseline/Anomaly"
]

CATEGORY_TO_COMPONENT = {
    "selftest": "System",
    "environment": "System",
    "system": "System",
    "windows_os": "Windows OS",
    "windows_update": "Windows OS",
    "installed_updates": "Windows OS",
    "hardware": "Hardware",
    "hardware_deep": "Hardware",
    "sensors": "Sensors",
    "storage": "Storage",
    "storage_health": "Storage",
    "processes": "Processes",
    "process": "Processes",
    "services": "Processes",
    "startup": "Processes",
    "scheduled_tasks": "Processes",
    "network": "Network",
    "network_deep": "Network",
    "security": "Security",
    "security_deep": "Security",
    "windows_events": "Events",
    "event_intelligence": "Events",
    "correlation": "Events",
    "drivers": "Drivers/GPU",
    "directx": "Drivers/GPU",
    "stress": "Stress",
    "baseline": "Baseline/Anomaly",
    "anomaly": "Baseline/Anomaly",
    "verification": "Baseline/Anomaly",
    "runner": "System",
}


def penalty(severity, finding=None):
    # Explicit score_weight lets postprocess mark context-only observations as non-penalizing.
    try:
        if finding is not None and isinstance(getattr(finding, 'data', None), dict) and 'score_weight' in finding.data:
            return int(finding.data.get('score_weight') or 0)
    except Exception:
        pass
    sev = str(severity).upper()
    if sev == "CRITICAL":
        return 18
    if sev == "WARNING":
        return 8
    # OBSERVE/INFO/PASS are context, not health failures. This prevents newly added intelligence from lowering score.
    return 0


def score_findings(findings):
    return max(0, min(100, 100 - sum(penalty(getattr(f, 'severity', 'OBSERVE'), f) for f in findings)))


def component_scores(findings):
    scores = {c: 100 for c in COMPONENTS}
    for f in findings:
        comp = CATEGORY_TO_COMPONENT.get(str(getattr(f, 'category', '')).lower(), "System")
        scores[comp] = max(0, scores[comp] - penalty(getattr(f, 'severity', 'OBSERVE'), f))
    return scores
