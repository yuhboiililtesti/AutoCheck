from pathlib import Path
import yaml


def load_config(path="config.yaml"):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError("config.yaml not found.")
    with p.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    for key in ["app", "thresholds", "stress_test", "scan_profiles", "output"]:
        if key not in cfg:
            raise ValueError(f"config.yaml missing required section: {key}")
    return cfg
