from collections import defaultdict
from core.scoring import score_findings
from core.utils import now_str, safe_json, safe_report_filename, safe_log_filename
from core.postprocess import prioritize


SEVERITY_ORDER = {"CRITICAL": 0, "WARNING": 1, "OBSERVE": 2, "INFO": 3, "PASS": 4}

CATEGORY_LABELS = {
    "environment": "Environment",
    "selftest": "Environment",
    "verification": "Hard Scan Comparison",
    "hardware": "Hardware",
    "hardware_deep": "Hardware Deep",
    "sensors": "Sensors",
    "processes": "Processes",
    "process": "Processes",
    "storage": "Storage",
    "storage_health": "Storage Health",
    "stress": "Stress Test",
    "windows_events": "Windows Events",
    "event_intelligence": "Event Intelligence",
    "drivers": "Drivers",
    "directx": "DirectX",
    "network": "Network",
    "network_deep": "Network Deep",
    "scheduled_tasks": "Scheduled Tasks",
    "services": "Services",
    "startup": "Startup",
    "system": "System",
    "windows_os": "Windows OS",
    "security": "Security",
    "security_deep": "Security Deep",
    "windows_update": "Windows Update",
    "installed_updates": "Installed Updates",
    "baseline": "Baseline",
    "anomaly": "Anomaly",
    "runner": "Runner",
    "correlation": "Correlation",
}

DETAIL_ORDER = [
    "System", "Environment", "Hardware", "Hardware Deep", "Sensors",
    "Storage", "Storage Health", "Processes", "Network", "Network Deep",
    "Security", "Security Deep", "Windows OS", "Windows Update",
    "Installed Updates", "Windows Events", "Event Intelligence", "Drivers",
    "DirectX", "Services", "Startup", "Scheduled Tasks", "Stress Test",
    "Hard Scan Comparison", "Correlation", "Baseline", "Anomaly", "Runner",
]


def label(category):
    return CATEGORY_LABELS.get(str(category).lower(), str(category).replace("_", " ").title())


def counts(findings):
    return {s: sum(1 for f in findings if f.severity == s) for s in ["CRITICAL", "WARNING", "OBSERVE", "INFO", "PASS"]}


def grade(score, c):
    if c["CRITICAL"]:
        return "Needs Attention"
    if c["WARNING"]:
        return "Needs Review"
    if score >= 90:
        return "Good"
    if score >= 75:
        return "Needs Review"
    return "Needs Attention"


def headline(c):
    if c["CRITICAL"]:
        return "Critical issues were found. Review before taking action."
    if c["WARNING"]:
        return "System is usable, but warnings need review."
    if c["OBSERVE"]:
        return "System looks healthy. Observations are informational unless symptoms exist."
    return "System looks healthy."


def sort_findings(findings):
    return prioritize(findings)


def short_detail(text, limit=360):
    text = str(text or "").strip()
    if len(text) <= limit:
        return text
    return text[:limit].rstrip() + " ... [trimmed; full details saved in logs]"


def clean_round_noise(text):
    text = str(text or "")
    text = text.replace("round detail: round detail: round detail:", "round detail:")
    text = text.replace("round detail: round detail:", "round detail:")
    return text


class ReportBuilder:
    def __init__(self, config, args):
        self.config = config
        self.args = args

    def _build_summary_text(self, findings, result, mode, score, status, c):
        important = [f for f in findings if f.severity in {"CRITICAL", "WARNING"}]
        observations = [f for f in findings if f.severity == "OBSERVE"]
        passes = [f for f in findings if f.severity == "PASS"]

        lines = []
        lines.append("=" * 76)
        lines.append(f"AUTOCHECK REPORT - {mode.upper()} SCAN")
        lines.append("=" * 76)
        lines.append(f"Generated: {now_str()}")
        lines.append(f"Score: {score}/100  |  Status: {status}")
        lines.append(f"Summary: {headline(c)}")
        lines.append(f"Counts: {c['CRITICAL']} critical, {c['WARNING']} warning, {c['OBSERVE']} observe, {c['INFO']} info, {c['PASS']} pass")
        lines.append("=" * 76)
        lines.append("")

        lines.append("COMPONENT SCORES")
        for comp, val in result.component_scores.items():
            lines.append(f"  {comp}: {val}/100")
        lines.append("")

        lines.append("TOP REVIEW ITEMS")
        if not important:
            lines.append("  No critical issues or warnings found.")
        else:
            for idx, f in enumerate(important[:8], 1):
                lines.append(f"  {idx}. [{f.severity}] {label(f.category)}: {f.title}")
                lines.append(f"     {short_detail(clean_round_noise(f.detail))}")
                lines.append(f"     Suggested review: {f.suggestion}")
            if len(important) > 8:
                lines.append(f"  {len(important) - 8} additional warning/critical item(s) saved in logs.")
        lines.append("")

        lines.append("OBSERVATIONS")
        if not observations:
            lines.append("  No observations requiring attention.")
        else:
            shown = observations[:10]
            for idx, f in enumerate(shown, 1):
                lines.append(f"  {idx}. {label(f.category)}: {f.title}")
                lines.append(f"     {short_detail(clean_round_noise(f.detail), 260)}")
            if len(observations) > len(shown):
                lines.append(f"  {len(observations) - len(shown)} additional observations saved in logs.")
        lines.append("")

        lines.append("QUICK PASSES")
        for f in passes[:10]:
            lines.append(f"  OK - {label(f.category)}: {f.title}")
        if len(passes) > 10:
            lines.append(f"  OK - {len(passes) - 10} additional checks passed.")
        if not passes:
            lines.append("  No pass signals recorded.")
        lines.append("")

        lines.append("LOGS")
        lines.append("  Summary report: reports/")
        lines.append("  Full detail log: logs/")
        lines.append("  Raw JSON log: logs/")
        lines.append("  Console stays summary-only unless --print-full is used.")
        lines.append("")

        lines.append("-" * 76)
        if c["CRITICAL"] or c["WARNING"]:
            lines.append("Next step: review TOP REVIEW ITEMS first. Everything else is informational unless symptoms exist.")
        elif c["OBSERVE"]:
            lines.append("Next step: no fix is required unless you are seeing symptoms.")
        else:
            lines.append("Next step: no action required.")
        lines.append("-" * 76)
        lines.append("")
        return "\n".join(lines)

    def _build_full_log_text(self, findings, result, mode, score, status, c):
        lines = []
        lines.append("=" * 76)
        lines.append(f"AUTOCHECK FULL LOG - {mode.upper()} SCAN")
        lines.append("=" * 76)
        lines.append(f"Generated: {now_str()}")
        lines.append(f"Score: {score}/100  |  Status: {status}")
        lines.append(f"Counts: {c['CRITICAL']} critical, {c['WARNING']} warning, {c['OBSERVE']} observe, {c['INFO']} info, {c['PASS']} pass")
        lines.append("=" * 76)
        lines.append("")

        lines.append("MODULE TIMING")
        for module, status_text in result.module_status.items():
            lines.append(f"  {module}: {status_text}")
        lines.append("")

        lines.append("METRICS SNAPSHOT")
        for k in sorted(result.metrics.keys()):
            lines.append(f"  {k}: {result.metrics[k]}")
        lines.append("")

        lines.append("DETAILS")
        grouped = defaultdict(list)
        for f in findings:
            grouped[label(f.category)].append(f)

        ordered = [x for x in DETAIL_ORDER if x in grouped] + sorted(x for x in grouped if x not in DETAIL_ORDER)
        for category in ordered:
            lines.append("")
            lines.append(f"[{category}]")
            for f in grouped[category]:
                lines.append(f"  {f.severity:<8} {f.title}")
                lines.append(f"           Detail: {clean_round_noise(f.detail)}")
                lines.append(f"           Suggestion: {f.suggestion}")
                if f.source:
                    lines.append(f"           Source: {f.source}")
                if f.data:
                    lines.append(f"           Data: {safe_json(f.data)}")
        lines.append("")
        return "\n".join(lines)

    def build(self, result, mode):
        findings = sort_findings(result.findings)
        score = score_findings(findings)
        c = counts(findings)
        status = grade(score, c)

        summary_text = self._build_summary_text(findings, result, mode, score, status, c)
        full_log_text = self._build_full_log_text(findings, result, mode, score, status, c)

        payload = {
            "mode": mode,
            "generated": now_str(),
            "score": score,
            "status": status,
            "counts": c,
            "component_scores": result.component_scores,
            "module_status": result.module_status,
            "metrics": result.metrics,
            "round_metrics": result.round_metrics,
            "findings": [f.to_dict() for f in findings],
            "saved_history": result.saved_history_path,
            "saved_baseline": result.saved_baseline_path,
        }

        summary_payload = {
            "mode": mode,
            "generated": payload["generated"],
            "score": score,
            "status": status,
            "counts": c,
            "component_scores": result.component_scores,
            "top_review_items": [
                f.to_dict() for f in findings if f.severity in {"CRITICAL", "WARNING"}
            ][:10],
            "observations": [
                f.to_dict() for f in findings if f.severity == "OBSERVE"
            ][:10],
        }

        saved_path = None
        saved_full_log = None
        saved_json_log = None

        if not self.args.no_save:
            report_dir = self.args.report_dir or self.config["output"]["reports_dir"]
            logs_dir = self.config.get("output", {}).get("logs_dir", "logs")

            saved_path = safe_report_filename(mode, report_dir)
            with open(saved_path, "w", encoding="utf-8") as f:
                f.write(summary_text)

            saved_full_log = safe_log_filename(mode, logs_dir, "full", ".txt")
            with open(saved_full_log, "w", encoding="utf-8") as f:
                f.write(full_log_text)

            saved_json_log = safe_log_filename(mode, logs_dir, "raw", ".json")
            with open(saved_json_log, "w", encoding="utf-8") as f:
                f.write(safe_json(payload))

        payload["saved_text_report"] = saved_path
        payload["saved_full_log"] = saved_full_log
        payload["saved_json_log"] = saved_json_log

        return {
            "text": summary_text,
            "full_text": full_log_text,
            "json": payload,
            "summary_json": summary_payload,
            "saved_path": saved_path,
            "saved_full_log": saved_full_log,
            "saved_json_log": saved_json_log,
        }
