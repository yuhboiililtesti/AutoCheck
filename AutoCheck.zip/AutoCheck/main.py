import argparse
import sys
from core.config import load_config
from core.runner import Runner
from core.report import ReportBuilder
from core.db import save_scan_to_db
from core.utils import safe_json


def parse_args():
    parser = argparse.ArgumentParser(
        prog="AutoCheck",
        description="AutoCheck read-only full system scanner"
    )
    parser.add_argument("mode", choices=["soft", "med", "hard", "monitor"], help="Scan depth: soft, med, hard, or monitor")
    parser.add_argument("--brief", action="store_true", help="Show compact report only")
    parser.add_argument("--full", action="store_true", help="Save full details into logs folder; console stays clean")
    parser.add_argument("--print-full", action="store_true", help="Print full details to console")
    parser.add_argument("--no-save", action="store_true", help="Do not save reports/history/database/logs")
    parser.add_argument("--set-baseline", action="store_true", help="Save current metrics as baseline for this mode")
    parser.add_argument("--no-baseline-compare", action="store_true", help="Skip baseline/history comparison")
    parser.add_argument("--no-stress", action="store_true", help="Skip hard-mode stress test")
    parser.add_argument("--json", action="store_true", help="Print compact JSON summary instead of text")
    parser.add_argument("--report-dir", type=str, help="Override report directory")
    return parser.parse_args()


def main():
    args = parse_args()
    config = load_config()

    if config.get("app", {}).get("readonly") is not True:
        raise RuntimeError("Safety stop: config app.readonly must be true.")

    if args.mode == "monitor":
        from modules.monitor import run_monitor
        run_monitor(config)
        return

    runner = Runner(config, args)
    result = runner.run(args.mode)

    builder = ReportBuilder(config, args)
    report = builder.build(result, args.mode)

    db_path = None
    if not args.no_save:
        db_path = save_scan_to_db(config, result, report)

    if args.json:
        print(safe_json(report["summary_json"]))
    else:
        if getattr(args, "print_full", False):
            print(report["full_text"])
        else:
            print(report["text"])

        if report.get("saved_path"):
            print(f"Saved summary report: {report['saved_path']}")
        if report.get("saved_full_log"):
            print(f"Saved full log: {report['saved_full_log']}")
        if report.get("saved_json_log"):
            print(f"Saved JSON log: {report['saved_json_log']}")
        if db_path:
            print(f"Saved database: {db_path}")

        print()
        print("No changes were made to your system.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print()
        print("Interrupted safely. No system changes were made.")
        sys.exit(130)
    except Exception as exc:
        print(f"AutoCheck failed safely: {exc}")
        sys.exit(1)
