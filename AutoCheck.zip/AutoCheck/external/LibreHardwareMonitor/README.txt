Optional LibreHardwareMonitor integration.

Place LibreHardwareMonitorLib.dll here to allow AutoCheck to attempt additional sensor reads through pythonnet.

AutoCheck does not bundle, install, or modify LibreHardwareMonitor.
